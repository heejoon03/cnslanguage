import java.util.*;

public class MainClass 
{	
	public static int[] solution(String[] timetable)
	{
		int[] answer = new int[4];
		//여기를 구현해 주세요.	
		return answer;
	}
	
	public static void main(String[] args) 
	{
		String[] timetable = { "09:00:00~12:00:00" , "12:10:00~14:10:00" , "14:20:00~15:20:00" };
		int[] ret = solution(timetable);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}







