import java.util.*;

class Conference{
	public int num;
	public int start;
	public int end;
	
	public Conference(int num, int start, int end){
		this.num = num;
		this.start = start;
		this.end = end;
	}
}

public class MainClass{		
	public static String solution(String[] conference){
		String answer = "";	
		ArrayList<Conference> con = new ArrayList<Conference>();
		for(int i = 0 ; i < conference.length; i++){
			int num = (conference[i].charAt(0) - '0');
			int start = (conference[i].charAt(2)-'0') * 10 + (conference[i].charAt(3)-'0');
			int end = (conference[i].charAt(5)-'0') * 10 + (conference[i].charAt(6)-'0');
			Conference c = new Conference(num, start, end);
			con.add(c);
		}
	
		con.sort(new Comparator<Conference>() {
			public int compare(Conference a, Conference b) {
				if(a.end > b.end) {
					return 1;
				}
				else {
					return -1;
				}
			}
		});
		
		ArrayList<Conference> result = new ArrayList<Conference>();
		result.add(con.get(0));
		for(int i = 1 ; i < conference.length; i++){
			if(result.get(i).end <= con.get(i).start){ //여기 수정
				result.add(con.get(i));
			}
		}
		for(Conference e : result){
			answer += String.valueOf(e.num) +" ";
		}
		answer = answer.substring(0, answer.length()-1);
		return answer;
	}
	
	public static void main(String[] args){	
		String[] conference = {"1-01:10", "2-05:06", "3-13:15", "4-14:17", "5-08:14", "6-03:12"};
		String ret = solution(conference);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
