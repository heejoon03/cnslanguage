import java.util.*;

public class MainClass
{	
	static ArrayList<ArrayList<Integer>> info = new ArrayList<ArrayList<Integer>>();
	static ArrayList<String> result = new ArrayList<String>();
	
	public static void search(int c){
		if(!result.contains(String.valueOf(c))){
			result.add(String.valueOf(c));
			result.add(" ");
		}
		for(int i = 0 ; i < info.get(c).size(); i++){
			if(info.get(c).get(i) != 0){
				int next = info.get(c).get(i);
				search(next);	
			}
		}
	}
	
	public static String solution(String[] maze){
		String answer = "";	
		
		int min = 10000;
		int max = 0;
		
		for(String e : maze){
			int start = Integer.valueOf(e.substring(0,2));
			int end = Integer.valueOf(e.substring(3,5));
			int tempMax = Math.max(start, end);
			int tempMin = Math.min(start, end);
			max = Math.max(max, tempMax);
			min = Math.min(min, tempMin);
		}
		
		for(int i = 0 ; i <= max ; i++){
			info.add(new ArrayList<Integer>());
		}
		
		for(String e : maze){
			int start = Integer.valueOf(e.substring(0,2));
			int end = Integer.valueOf(e.substring(3,5));
			info.get(start).add(end);
			info.get(end).add(start);
		}
		
		for(int i = 0 ; i < info.size(); i++){
			Collections.sort(info.get(i));
		}
		
		search(min);
		result.remove(result.size()-1);
		for(String e : result){
			answer += e;
		}
		return answer;
	}
	
	public static void main(String[] args){	
		String[] maze = {"10-13", "13-17", "17-10", "39-10", "25-13", "13-39"};
		String ret = solution(maze);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
