import java.util.*;

public class MainClass 
{	
	static boolean[] visit;
	static int[][] adj;
	static boolean flag = false;
	static int n;
	static int k;
	static int a;
	static int b;
	static String ans;

	public static boolean func_a(int v, String s)
    {
		if (v == b)
		{
			flag = true;
			ans = s;
		}
		else
		{
			for (int i = 1; i <= n; i++)
			{
				if (!visit[i] && adj[v][i] == 1)
				{
					visit[i] = true;
					func_@@@(@@@);
				}
			}
		}
		return flag;
	}

	public static void func_b(String[] x, int[] y)
    {
		n = x.length;
		k = x[0].length();
		a = y[0];
		b = y[1];
		ans = "";

		for (int i = 1; i < x.length; i++)
		{
			for (int j = i + 1; j <= x.length; j++)
			{
				if (func_c(x[i - 1], x[j - 1]))
				{
					adj[i][j] = 1;
					adj[j][i] = 1;
				}
			}
		}
	}

	public static boolean func_c(String s1, String s2)
    {
		int cnt = 0;
		for (int i = 0; i < k; i++)
		{
			if (s1.charAt(i) != s2.charAt(i))
			{
				if (++cnt >= 2)
				{
					return false;
				}
			}
		}
		if (cnt == 0)
			return false;
		return true;
	}

	public static String solution(String[] hamming, int[] question)
	{
		String answer = "";
		visit = new boolean[1001];
		adj = new int[hamming.length + 1][hamming.length + 1];

		func_@@@(@@@);

		visit[question[0]] = true;

		if(!func_@@@(@@@))
			answer = "-1";
		else
			answer = ans;
		return answer;
	}
	public static void main(String[] args) 
	{
		String[] hamming = { "000", "111", "010", "110", "001" };
		int[] question = { 1, 2 };
		String ret = solution(hamming, question);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}







