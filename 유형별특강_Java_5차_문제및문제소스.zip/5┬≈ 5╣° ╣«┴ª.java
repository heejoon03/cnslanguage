import java.util.*;

public class MainClass 
{	
	public static ArrayList<String> solution(String position)
	{
		ArrayList<String> answer = new ArrayList<String>();

		int[] rowDir = { 0, -1, 0, 1 };
		int[] colDir = { -1, 0, 1, 0 };

		for (int i = 0; i < 4; i++)
		{
			char moveCol = position.charAt(0);
			char moveRow = position.charAt(1);
			while (true){
				moveCol = (char)(@@@);
				moveRow = (char)(@@@);
				if (moveRow >= @@@ && moveCol >= @@@ && moveRow <= @@@ && moveCol <= @@@)
					answer.Add(moveCol + "" + moveRow);
				else
					break;
			}
		}

		return answer;
	}
	public static void main(String[] args) 
	{
		String position = "d4";
		ArrayList<String> ret = solution(position);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}







