import java.util.*;

public class MainClass 
{	
	public static ArrayList<String> solution(String[] timetable, String interval)
	{
		//interval마다 몇번의 알람이 울리는가
		ArrayList<String> answer = new ArrayList<String>();

		int intervalToInt = (interval.charAt(0) - '0') * 10 + (interval.charAt(1) - '0');

		String startTime = timetable[0];
		String endTime = timetable[1];

		while(true)
        {
			int hour = (startTime.charAt(0) - '0') * 10 + (startTime.charAt(1) - '0');
			int min = (startTime.charAt(3) - '0') * 10 + (startTime.charAt(4) - '0');

			min += intervalToInt;

			if(min >= 60)
            {
				hour += (60 - min) + 10;
				min -= 60;
            }
			String cHour = String.valueOf(hour);
			String cMin = String.valueOf(min);

			if(cHour.length() == 1)
				cHour = "0" + cHour;
			if(cMin.length() == 1)
				cMin = "0" + cMin;

			startTime = cHour + ":" + cMin;

			int cStartTimeHour = (startTime.charAt(0) - '0') * 10 + (startTime.charAt(1) - '0');
			int cStartTimeMin = (startTime.charAt(3) - '0') * 10 + (startTime.charAt(4) - '0');
			int endTimeHour = (endTime.charAt(0) - '0') * 10 + (endTime.charAt(1) - '0');
			int endTimeMin = (endTime.charAt(3) - '0') * 10 + (endTime.charAt(4) - '0');


			if (cStartTimeHour > endTimeHour)
				break;
			else if (cStartTimeHour == endTimeHour && cStartTimeMin > endTimeMin)
				break;
			else if (cStartTimeHour == endTimeHour && cStartTimeMin == endTimeMin)
            {
				answer.add(startTime);
				break;
			}
			answer.add(startTime);
		}
		
		return answer;
	}
	public static void main(String[] args) 
	{
		String[] timetable1 = {"12:00", "13:40"};
		String interval1 = "15";
		ArrayList<String> ret1 = solution(timetable1, interval1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		String[] timetable2 = { "15:20", "17:40" };
		String interval2 = "20";
		ArrayList<String> ret2 = solution(timetable2, interval2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}







