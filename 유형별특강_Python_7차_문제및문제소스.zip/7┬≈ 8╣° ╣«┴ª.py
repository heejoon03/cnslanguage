#추가로 필요한 코드는 여기에 구현해 주세요.

def solution(seat1, seat2):
    answer = 0
    #코드를 구현해 주세요.
    return answer

seat1 = 3
seat2 = 6
ret = solution(seat1, seat2)
print("solution 함수의 반환값은", ret, "입니다.")