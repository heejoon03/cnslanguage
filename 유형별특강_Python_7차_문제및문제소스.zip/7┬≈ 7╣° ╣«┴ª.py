#추가적으로 필요한 코드는 이곳에 작성해 주세요.

def solution(coins, price):
    answer = []
    #여기를 구현해 주세요.
    return answer

coins = [4, 5, 2, 6, 3, 4]
price = 13
ret = solution(coins, price)
print("solution 함수의 반환값은", ret, "입니다.")