def solution(town, relation):
    answer = [False] * len(relation)
    group = [0] * 10010

    town.sort(key = lambda x : x[0], reverse = False)

    endX = town[0][1]
    groupNum = 1
    group[town[0][2]] = 1

    for i in range(1, len(town)):
        if town[i][0] < endX:
            group[town[i][2]] = groupNum
            endX = max(endX, town[i][1])
        else :
            groupNum += 1
            group[town[i][2]] = groupNum
            enxX = town[i][1]

    for i in range(len(relation)):
        answer[i] = group[relation[i][0]] == group[relation[i][1]]

    return answer

town = [[1, 5, 2], [3, 7, 4], [7, 9, 1], [10, 13, 3]]
relation = [[1, 3], [1, 4]]
ret = solution(town, relation)
print("solution 함수의 반환값은", ret, "입니다.")