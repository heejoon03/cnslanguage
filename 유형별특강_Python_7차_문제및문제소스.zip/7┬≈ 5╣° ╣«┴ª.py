class Pair:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Prison:
    def __init__(self):
        self.prisonerA = 0
        self.prisonerB = 0
        self.jails = []
        self.visit = []
        self.length = 0

    def func_a(self, j, n):
        for i in range(n+1):
            self.jails.append(list())
        for i in range(len(j)):
            self.jails[j[i][0]].append(Pair(j[i][1], j[i][2]))
            self.jails[j[i][1]].append(Pair(j[i][0], j[i][2]))

    def func_b(self, a, b):
        return max(a,b)

    def func_c(self, j, t, m):
        if j == self.prisonerB:
            self.length = t - m
        if self.length != 0:
            return
        self.visit[j] = True
        for i in range(len(self.jails[j])):
            if self.visit[self.jails[j][i].x] == False:
                self.func_@@@(@@@)

    def solution(self, a, b, n, jail):
        answer = 0
        self.prisonerA = a
        self.prisonerB = b
        self.visit = [False] * (n+1)
        self.func_@@@(@@@)
        self.func_@@@(@@@)
        answer = self.length
        return answer



a = 1
b = 9
n = 9
jail = [[1, 2, 8], [2, 3, 6], [2, 4, 5], [2, 5, 10], [9, 5, 6], [6, 5, 14], [6, 7, 7], [8, 6, 7]]
p = Prison()
ret = p.solution(a, b, n, jail)
print("solution 함수의 반환값은", ret, "입니다.")