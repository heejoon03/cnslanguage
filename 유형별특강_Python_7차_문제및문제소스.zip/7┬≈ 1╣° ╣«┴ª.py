class Tree:
    def __init__(self, tree, cnt):
        self.dp = [0] * 300010
        self.v = []
        self.num = cnt
        for i in range (0,300010):
            self.v.append(list())
        for i in range(0, self.num-1):
            self.v[tree[i][0]].append(tree[i][1])
            self.v[tree[i][1]].append(tree[i][0])
        self.result = 0
    def Combination(self, n):
        return n * (n - 1) // 2
    def Search(self, current):
        self.dp[current] = 1
        for e in self.v[current]:
            if self.dp[e] == 0:
                self.dp[current] += self.Search(e)
        self.result += self.Combination(self.num) - self.Combination(self.num - self.dp[current])
        return self.dp[current]

def solution(tree, cnt):
    answer = 0
    t = Tree(tree, cnt)
    t.Search(1)
    answer = t.result 
    return answer

tree1 = [[1,3], [2,3]]
cnt1 = 3
ret1 = solution(tree1, cnt1)
print("solution 함수의 반환값은", ret1, "입니다.")

tree2 = [ [6, 2 ], [7, 5], [3, 4], [5, 6], [1, 5], [4, 1], [8, 6 ]]
cnt2 = 8
ret2 = solution(tree2, cnt2)
print("solution 함수의 반환값은", ret2, "입니다.")