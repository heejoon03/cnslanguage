def solution(k, result):
    answer = [False] * len(result)
    index = 0

    for i in range(len(result)):
        restRound = k - max(result[i][0], result[i][1])
        if result[i][0] >= result[i][1] and @@@:
            answer[index] = False
            index += 1
        elif result[i][0] < result[i][1] and @@@:
            answer[index] = False
            index += 1
        else :
            answer[index] = True
            index += 1
    return answer

k = 5
result = [[5, 5], [5, 1], [0, 3], [1, 4]]
ret = solution(k, result)
print("solution 함수의 반환값은", ret, "입니다.")