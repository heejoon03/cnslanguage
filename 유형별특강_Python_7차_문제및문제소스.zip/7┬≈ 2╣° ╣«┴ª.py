def solution(sentence):
    answer = [0] * len(sentence)
    temp = ""

    for i in range(len(sentence)):
        findNotEqual = 0
        isBreak = 0
        for findNotEqual in range(len(sentence[i]) // 2):
            if sentence[i][findNotEqual] != sentence[i][len(sentence[i]) - 1 - findNotEqual]:
                isBreak = 1
                break
        if isBreak == 0:
            findNotEqual += 1
        if findNotEqual != len(sentence[i])
            temp = ""
            for k in range(len(sentence[i])):
                if k != findNotEqual:
                    temp += sentence[i][k]   
            checkIndex = 0
            isBreak = 0
            for checkIndex in range(len(temp)):
                if temp[checkIndex] != temp[len(temp) - 1 - checkIndex]:
                    isBreak = 1
                    break
            if isBreak == 0:
                checkIndex += 1
            if checkIndex == len(temp):
                answer[i] = 1
                continue
            temp = ""
            for k in range(len(sentence[i])):
                if k != len(sentence[i]) - 1 - findNotEqual:
                    temp += sentence[i][k]
            checkIndex = 0
            isBreak = 0
            for checkIndex in range(len(temp)):
                if temp[checkIndex] != temp[len(temp) - 1 - checkIndex]:
                    isBreak = 1
                    break
            if isBreak == 0:
                checkIndex += 1
            if checkIndex == len(temp):
                answer[i] = 1
            else :
                answer[i] = 2
        else :
            answer[i] = 0
    return answer

sentence = ["ada", "summuus", "cavva", "cavvat", "oleole", "comwwmoc", "comwwtmoc"]
ret = solution(sentence)
print("solution 함수의 반환값은", ret, "입니다.")