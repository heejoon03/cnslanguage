import java.util.*;

public class Main 
{	
	public static int solution(String stick){
		int answer = 0;
		
		int cutLocation = 0;
		int cutStickCount = 0;
		 
		for(int i = 0 ; i < stick.length() ; i++)
		{
		    if(stick.charAt(i) == '(')
		    {
		    	cutLocation = @@@;
		        cutStickCount = @@@;
		    }
		    else if(stick.charAt(i) == ')' && cutLocation == 1)
		    {
		        cutStickCount = @@@;
		        answer = @@@;
		        cutLocation = @@@;
		    }
		    else if(stick.charAt(i) == ')' && cutLocation != 1)
		    {
		    	answer = @@@;
		    	cutLocation = @@@;
		        cutStickCount = @@@;
		    }
		}	
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String stick1 = "()(((()())(())()))(())";
		int ret1 = solution(stick1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		
		String stick2 = "(((()(()()))(())()))(()())";
		int ret2 = solution(stick2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
