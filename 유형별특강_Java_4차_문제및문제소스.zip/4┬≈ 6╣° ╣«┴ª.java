import java.util.*;

interface Attendance{
	public void record(String[] attendance);
	public boolean check();
}

class Employee @@@
{
	private int[] attendanceTime;
	
	public Employee(){
		@@@
	}
	
	@@@{
		for(int i = 0 ; i < attendance.length; i++) {
			int attHour = (attendance[i].charAt(6) - '0') * 10 + (attendance[i].charAt(7) - '0');
			int enterHour = (attendance[i].charAt(0) - '0') * 10 + (attendance[i].charAt(1) - '0');
			int enterMin = (attendance[i].charAt(3) - '0') * 10 + (attendance[i].charAt(4) - '0');
			
			if(@@@)
			{
				attendanceTime[attHour] += 1;
			}
			else if(@@@)
			{
				attendanceTime[attHour] += 1;
			}
		}
	}
	
	@@@{
		int cnt = 0;
		for(int e : attendanceTime) {
			@@@;
		}
		return @@@;
	}
}

class Executive @@@
{
	private int[] attendanceTime;
	
	public Executive(){
		@@@
	}
	
	@@@{
		for(int i = 0 ; i < attendance.length; i++) {
			int attHour = (attendance[i].charAt(6) - '0') * 10 + (attendance[i].charAt(7) - '0');
			int enterHour = (attendance[i].charAt(0) - '0') * 10 + (attendance[i].charAt(1) - '0');
			int enterMin = (attendance[i].charAt(3) - '0') * 10 + (attendance[i].charAt(4) - '0');
			
			if(@@@)
			{
				attendanceTime[attHour] += 1;
			}
			else if(@@@)
			{
				attendanceTime[attHour] += 1;
			}
		}
	}
	
	@@@{
		int cnt = 0;
		for(int e : attendanceTime) {
			@@@;
		}
		
		return @@@;
	}
}

public class Main 
{	
	public static boolean[] solution(String[] employee, String[] executive){
		boolean[] answer = new boolean[2];
		Employee emplo = new Employee();
		Executive execu = new Executive();
		
		emplo.record(employee);
		execu.record(executive);
		
		answer[0] = emplo.check();
		answer[1] = execu.check();
		
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String[] employee = {"07:30_07", "08:20_08", "09:10_07", "08:10_07", "10:40_11", "10:20_08", "11:00_11", "11:20, 11", "07:50_08", "12:30_10"};
		String[] executive = {"08:10_07", "10:40_11", "10:20_08", "11:00_11", "10:30_10"};
		boolean[] ret = solution(employee, executive);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret)  + " 입니다.");
	}
}
