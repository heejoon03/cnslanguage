import java.util.*;

public class Main 
{	
	public static void func_a(int[] arr, String s) {
		for(int i = 0 ; i < s.length(); i++) {
			if(s.charAt(i) == 'W') {
				arr[0]++;
			}
			else {
				arr[1]++;
			}
		}
	}
	
	public static int func_b(String s, char b) {
		int answer = 0;
		for(int i = s.length() - 1; i >= 0 ; i--) {
			if(s.charAt(i) == b) {
				answer++;
			}
			else{
				break;
			}
		}
		return answer;
	}
	
	public static int func_c(String s, char b) {
		int answer = 0;	
		for(int i = 0; i < s.length(); i++) {
			if(s.charAt(i) == b) {
				answer++;
			}
			else {
				break;
			}
		}	
		return answer;
	}
	
	public static int solution(String balls){
		int answer = 500000;
		
		int[] check = new int[2];
		
		func_@@@(@@@);
		
		int case1 = func_@@@(@@@);
		int case2 = func_@@@(@@@);
		int case3 = func_@@@(@@@);
		int case4 = func_@@@(@@@);
		
		if(check[0] - case1 < answer) {
			answer = check[0] - case1;
		}
		if(check[0] - case2 < answer) {
			answer = check[0] - case2;
		}
		if(check[1] - case3 < answer) {
			answer = check[1] - case3;
		}
		if(check[1] - case4 < answer) {
			answer = check[1] - case4;
		}
		
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String balls1 = "WBBBWBWWW";
		int ret1 = solution(balls1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		
		String balls2 = "BBWBBBBW";
		int ret2 = solution(balls2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
