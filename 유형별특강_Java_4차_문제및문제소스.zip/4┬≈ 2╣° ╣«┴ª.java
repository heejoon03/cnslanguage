import java.util.*;

public class MainClass
{	
	public static int cnt = 0;
	public static boolean[][] visit = new boolean[7][7];
	public static String[] ani = new String[7];
	public static int[] rowDir = {0, 1, 0, -1};
	public static int[] colDir = {-1, 0 ,1, 0};
	
	public static void search(int r, int c) {
		visit[r][c] = true;
		
		for(int i = 0 ; i < 4; i++) {
			int nextRow = r + rowDir[i];
			int nextCol = c + colDir[i];
			
			if(nextRow >= 0 && nextCol >= 0) {
				if(nextRow < 7 && nextCol < 7) {
					if(!visit[nextRow][nextCol]) {
						if(ani[nextRow].charAt(nextCol) == ani[r].charAt(c)) {
							cnt++;
							visit[nextRow][nextCol] = true;
							search(nextRow, nextCol);
						}
					}
				}
			}
		}
	}

	public static int solution(String[] anipang){
		int answer = 0;
		ani = anipang;	
		for(int i = 0 ; i < 7; i++) {
			for(int j = 0 ; j < 7; j++) {
				search(i,j);
				if(cnt >= 3) {
					answer++;
				}
				cnt = 0;
			}
		}
		return answer;
	}

	public static void main(String[] args)
	{	
		String[] anipang = {"MCBRAPC", "MMROPPO", "BBCCAMB", "APMPORA", "BMACOMB", "RPOAORP", "MOPMPBB"};
		int ret = solution(anipang);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
