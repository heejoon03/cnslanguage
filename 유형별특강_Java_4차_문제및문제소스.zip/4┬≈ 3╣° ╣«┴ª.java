import java.util.*;

public class Main 
{	
	static String str = "";
	static int length = 0;
	static boolean[] visit = new boolean[10];
	static ArrayList<String> temp = new ArrayList<String>();
	
	public static void search(int v, int c, String s) {
		if(c == length) {
			temp.add(s);
		}
		else {
			for(int i = 0 ; i <= 9 ; i++) {
				if(!visit[i]) {
					if(str.charAt(c) == '<') {
						if(v >= i) {
							continue;
						}
					}
					else {
						if (v <= i) {
							continue;
						}
					}
					visit[i] = true;
					search((i+1), c + 1 , s + (i+1));
				}
			}
		}	
		visit[v] = false;
	}
	
	public static String[] solution(String A){
		String[] answer = new String[2];
		length = A.length();
		str = A;
		
		for(int i = 0 ; i <= 9 ; i++) {
			visit[i] = true;
			search(i, 0, i + "");
		}
		
		answer[0] = temp.get(temp.size() - 1);
		answer[1] = temp.get(0);
		
		str = "";
		length = 0;
		visit = new boolean[10];
		temp = new ArrayList<String>();
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String A1 = "<>";
		String[] ret1 = solution(A1);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret1) + " 입니다.");
		
		String A2 = "><<<>>><<";
		String[] ret2 = solution(A2);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret2) + " 입니다.");
	}
}
