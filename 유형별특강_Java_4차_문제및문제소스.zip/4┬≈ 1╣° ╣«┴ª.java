import java.util.*;

public class MainClass 
{		
	public static int solution(String equation)
	{
		int answer = 0;
		
		Stack<Integer> s = new Stack<Integer>();
		
		for(int i = 0 ; i < equation.length() ; i++)
		{
			if(equation.charAt(i) >= '0' && equation.charAt(i) <= '9'){
				s.add(equation.charAt(i) - '0');
			}
			else
			{
				if(equation.charAt(i) == ' '){
					continue;
				}
				int a = s.pop();
				int b = s.pop();
				if(equation.charAt(i) == '+'){
					s.add(a+b);
				}
				else if(equation.charAt(i) == '-'){
					s.add(a-b);
				}
				else if(equation.charAt(i) == '*'){
					s.add(a*b);
				}
				else if(equation.charAt(i) == '/'){
					if(a == 0){
						s.add(0);
					}
					else{
						s.add(b/a);
					}
				}
			}
		}
		answer = s.pop();
		return answer;
	}
	
	public static void main(String[] args) 
	{
		String equation1 = "3 5 7 * +";
		int ret1 = solution(equation1);
		System.out.println("solution 메소드의 반환 값은 " + ret1 + " 입니다.");
		
		String equation2 = "6 8 + 2 /";
		int ret2 = solution(equation2);
		System.out.println("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
		
		String equation3 = "1 2 3 * + 4 5 - 6 * +";
		int ret3 = solution(equation3);
		System.out.println("solution 메소드의 반환 값은 " + ret3 + " 입니다.");
	}
}