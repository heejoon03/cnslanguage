import java.util.*;

public class Main 
{	
	public static int solution(String extension, String[] files){
		int answer = 0;
		//여기를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String extension = "doc";
		String[] files = {"lg.doc", "lg.xls", "lgcns.doc", "lgcns.docx"};
		int ret = solution(extension, files);
		System.out.println("solution 함수의 반환 값은 " + ret  + " 입니다.");
	}
}
