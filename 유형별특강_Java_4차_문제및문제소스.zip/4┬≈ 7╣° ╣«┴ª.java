import java.util.*;

public class Main 
{	
	public static int solution(int dice, String coin){
		int answer = 0;
		//여기를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String coin = "FFFBF";
		int dice = 5;
		int ret = solution(dice, coin);
		System.out.println("solution 함수의 반환 값은 " + ret  + " 입니다.");
	}
}
