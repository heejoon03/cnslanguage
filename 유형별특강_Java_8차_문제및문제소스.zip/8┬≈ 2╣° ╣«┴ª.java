import java.util.*;

public class MainClass{	

	static int maxCnt = 0;
	static int row = 0;
	static int col = 0;
	static int[] rowDir = {-1, 0, 1, 0};
	static int[] colDir = {0, -1, 0, 1};
	static char[] alpha;
	static int[][] visited;
	static String[] b;
	
	public static void search(int r, int c, int m) {
		maxCnt = Math.max(maxCnt, m);
		for(int i = 0 ; i < 4; i++) {
			int nextRow = r + rowDir[i];
			int nextCol = c + colDir[i];
			if(nextRow >= 0 && nextRow < row && nextCol >= 0 && nextCol < col) {
				if(alpha[b[nextRow].charAt(nextCol) - 'A'] == 0) {
					visited[nextRow][nextCol] = 1;
					alpha[b[nextRow].charAt(nextCol) - 'A']++;
					search(nextRow, nextCol, m);
					visited[nextRow][nextCol] = 0;
					alpha[b[nextRow].charAt(nextCol) - 'A']--;
				}
			}
		}
	}
	
	public static int solution(String[] board){
		int answer = 0;
		maxCnt = 0;
		alpha = new char[26];
		visited = new int[board.length][board[0].length()];
		alpha[board[0].charAt(0) - 'A']++;
		b = board;
		visited[0][0] = 1;
		row = board.length;
		col = board[0].length();
		search(0,0,1);
		answer = maxCnt;
		return answer;
	}
	
	public static void main(String[] args){	
		String board1[] = {"CAAB", "ADCB"};
		int ret1 = solution(board1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		String board2[] = {"HFDFFB", "AJHGDH", "DGAGEH"};
		int ret2 = solution(board2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
		String board3[] = {"IEFCJ", "FHFKC", "FFALF", "HFGCF", "HMCHH"};
		int ret3 = solution(board3);
		System.out.println("solution 함수의 반환 값은 " + ret3 + " 입니다.");
	}
}
