import java.util.*;

//추가적으로 필요한 코드는 이곳에 작성해 주세요.

public class MainClass{	
	public static int solution(String card){
		int answer = 0;
		//이곳에 코드를 작성해 주세요.
		return answer;
	}
	
	public static void main(String[] args){	
		String card1 = "27123";
		int ret1 = solution(card1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		String card2 = "77777777777777777";
		int ret2 = solution(card2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
