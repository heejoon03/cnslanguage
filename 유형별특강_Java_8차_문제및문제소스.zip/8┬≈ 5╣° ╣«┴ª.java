import java.util.*;

interface Vaccine
{
	public void Create();
	public double Inoculate();
}

class Manssen @@@
{
	public int vaccineCnt = 0;
	public int total = 0;
	public Manssen(String[] vaccines) {
		for(int i = 0 ; i < vaccines.length ; i++) {
			if(vaccines[i].substring(0, vaccines[i].indexOf('-')).equals("Manssen")) {
				vaccineCnt = Integer.valueOf(vaccines[i].substring(vaccines[i].indexOf('-')+1, vaccines[i].length()));
				break;
			}
		}
	}
	public @@@{
		for(int i = 1; i <= vaccineCnt ; i++) {
			if(@@@) {
				continue;
			}
			else {
				total++;
			}
		}
	}
	public @@@{
		double danger = 0;
		for(int i = 1 ; i <= total; i++) {
			if(@@@) {
				danger++;
			}
		}
		return Math.round(@@@ * 10000) / 100.0;
	}
}

class Mfizer @@@
{
	public int vaccineCnt = 0;
	public int total = 0;
	public Mfizer(String[] vaccines) {
		for(int i = 0 ; i < vaccines.length ; i++) {
			if(vaccines[i].substring(0, vaccines[i].indexOf('-')).equals("Mfizer")) {
				vaccineCnt = Integer.valueOf(@@@);
				break;
			}
		}
	}
	public @@@{
		for(int i = 1; i <= vaccineCnt ; i++) {
			if(i % 21 == 0) {
				continue;
			}
			else {
				total++;
			}
		}
	}
	public @@@{
		double danger = 0;
		for(int i = 1 ; i <= total; i++) {
			if(@@@) {
				danger++;
			}
		}
		return Math.round(@@@ * 10000) / 100.0;
	}
}

class Minovac @@@
{
	public int vaccineCnt = 0;
	public int total = 0;
	public Minovac(String[] vaccines) {
		for(int i = 0 ; i < vaccines.length ; i++) {
			if(vaccines[i].substring(0, vaccines[i].indexOf('-')).equals("Minovac")) {
				vaccineCnt = Integer.valueOf(@@@);
				break;
			}
		}
	}
	public @@@{
		int bad = 0;
		for(int i = 1; i <= vaccineCnt ; i++) {
			if(@@@) {
				bad++;
				continue;
			}
			else {
				total++;
			}
		}
		@@@;
	}
	public @@@{
		double danger = 0;
		int nest = 1;
		for(int i = 1 ; i <= total; i++) {
			if(i % 3 == 0) {
				danger += nest;
				@@@;
			}
		}
		return Math.round(@@@ * 10000) / 100.0;
	}
}

public class MainClass{	
	public static double[] solution(String[] vaccines){
		double[] answer = new double[3];
		Vaccine[] vaccineInfo = new Vaccine[3];
		vaccineInfo[0] = new Manssen(vaccines);
		vaccineInfo[1] = new Mfizer(vaccines);
		vaccineInfo[2] = new Minovac(vaccines);
		for(int i = 0 ; i < 3; i++) {
			vaccineInfo[i].Create();
			answer[i] = vaccineInfo[i].Inoculate();
		}
		return answer;
	}
	
	public static void main(String[] args){	
		String[] vaccines = {"Manssen-100", "Mfizer-200", "Minovac-300"};
		double[] ret = solution(vaccines);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}
