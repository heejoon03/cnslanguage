import java.util.*;

public class MainClass{	
	public static int solution(ArrayList<Integer> sequence){
		int answer = 0;
		ArrayList<Integer> s = new ArrayList<Integer>();
		sequence.add(0,0);
		s.add(0);
		for(int i = 0 ; i < sequence.size(); i++) {
			s.add(sequence.get(i));
		}
		for(int i = 1 ; i < sequence.size() ; i++) {
			while(s.size() != 0 && @@@){
				int temp = s.get(s.size()-1);
				s.remove(s.size()-1);
				answer = Math.max(answer, sequence.get(temp) * @@@);
			}
			s.add(i);
		}
		return answer;
	}
	
	public static void main(String[] args){	
		ArrayList<Integer> sequence = new ArrayList<Integer>();
		sequence.add(2);
		sequence.add(1);
		sequence.add(4);
		sequence.add(5);
		sequence.add(1);
		sequence.add(3);
		sequence.add(3);
		int ret = solution(sequence);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
