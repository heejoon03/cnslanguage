import java.util.*;

public class MainClass{	
	public static int endIndex = 0;
	public static ArrayList<Integer> s = new ArrayList<Integer>();
	
	public static void heapify(int heapIndex, int end)
	{
		int left = 2 * heapIndex;
		int right = 2 * heapIndex + 1;
		int large = 0;
		if(right <= end) {
			large = s.get(left) > s.get(right) ? left : right;
		}
		else if(left <= end) {
			large = left;
		}
		else {
			return;
		}
		if(s.get(large) > s.get(heapIndex)) {
			int temp = s.get(large);
			s.set(large, s.get(heapIndex));
			s.set(heapIndex, temp);
			heapify(large, end);
		}
	}
	
	public static void build(){
		for(int i = endIndex/2 ; i >= 1 ; i--) {
			heapify(i, endIndex);
		}
	}
	
	public static int[] solution(int[] sequence){
		int[] answer = new int[sequence.length];
		endIndex = sequence.length;
		s.add(0);
		for(int e : sequence){
			s.add(e);
		}
		build();
		for(int i = endIndex ; i >= 1 ; i--){
			int temp = s.get(0);
			s.set(0, s.get(i));
			s.set(i, temp);
			heapify(0, i);
		}
		for(int i = 0 ; i <answer.length; i++){
			answer[i] = s.get(i);
		}
		return answer;
	}
	
	public static void main(String[] args){	
		int[] sequence = {3,6,4,8,9,7};
		int[] ret = solution(sequence);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}
