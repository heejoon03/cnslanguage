import java.util.*;

class Edge{
	public int n1 = 0;
	public int n2 = 0;
	public int distance = 0;
	public Edge(int n1, int n2, int distance) {
		this.n1 = n1;
		this.n2 = n2;
		this.distance = distance;
	}
}

public class MainClass{	
	public static ArrayList<Integer> set = new ArrayList<Integer>();
	
	public static int func_a(int x) {
		if(set.get(x) == x) {
			return x;
		}
		set.set(x, func_@@@(@@@));
		return set.get(x);
	}
	
	public static boolean func_b(int a, int b) {
		a = func_@@@(@@@);
		b = func_@@@(@@@);
		return a == b;
	}
	
	public static void func_c(int a, int b) {
		a = func_@@@(@@@);
		b = func_@@@(@@@);
		if(a < b) {
			set.set(b, a);
		}
		else {
			set.set(a, b);
		}
	}
	
	public static int solution(int[][] tree){
		int answer = 0;
		ArrayList<Edge> v = new ArrayList<Edge>();
		for(int i = 0 ; i < tree.length; i++) {
			for(int j = 0 ; j < tree.length; j++) {
				v.add(new Edge(i,j,tree[i][j]));
			}
		}

		Collections.sort(v, (c1, c2) -> c1.distance - c2.distance);
		
		for(int i = 0 ; i < tree.length; i++) {
			set.add(i);
		}
		for(int i = 0 ; i < v.size(); i++) {
			if(!func_@@@(@@@)) {
				answer += v.get(i).distance;
				func_@@@(@@@);
			}
		}
		return answer;
	}
	
	public static void main(String[] args){	
		int[][] tree = { {0, 5, 10, 8, 7}, {5, 0, 5, 3, 6}, {10, 5, 0, 1, 3} , {8, 3, 1, 0, 1}, {7, 6, 3, 1, 0}};
		int ret = solution(tree);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
