import java.util.*;

public class MainClass{	
	public static int[] alpha;
	public static String sentence;
	public static int search(char before, int pos) {
		int cnt = 0;
		if(pos == sentence.length()) {
			cnt++;
		}
		else {
			for(int i = 0 ; i < 26 ; i++) {
				if(alpha[i] >= 1 && 'A'+i != before) {
					alpha[i]--;
					search((char)('A'+i), pos+1);
					alpha[i]++;
				}
			}
		}
		return cnt;
	}
	
	public static int solution(String s){
		int answer = 0;
		alpha = new int[26];
		sentence = s;
		for(int i = 0 ; i < s.length(); i++) {
			alpha[s.charAt(i) - 'A']++;
		}
		answer = search(' ',0);
		return answer;
	}
	
	public static void main(String[] args){	
		String s1 = "AB";
		int ret1 = solution(s1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		String s2 = "AAAB";
		int ret2 = solution(s2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
		String s3 = "AABBBAA";
		int ret3 = solution(s3);
		System.out.println("solution 함수의 반환 값은 " + ret3 + " 입니다.");
		String s4 = "ABCDEFG";
		int ret4 = solution(s4);
		System.out.println("solution 함수의 반환 값은 " + ret4 + " 입니다.");
	}
}
