import java.util.*;
//추가적으로 필요한 코드는 이곳에 작성해 주세요.

public class MainClass{	
	public static int solution(int price, int[][] atm){
		int answer = 0;
		//이곳에 코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args){	
		int price = 20;
		int[][] atm = {{5, 3}, {10, 2}, {1, 5}};
		int ret = solution(price, atm);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
