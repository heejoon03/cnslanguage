// You may use include as below.
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

long long solution(long long num) {
    // Write code here.
    long long answer = 0;
    return answer;
}

// The following is main function to output testcase.
int main() {
    long long num = 9949999;
    long long ret = solution(num);

    // Press Run button to receive output. 
    printf("Solution: return value of the function is %lld .\n", ret);
}