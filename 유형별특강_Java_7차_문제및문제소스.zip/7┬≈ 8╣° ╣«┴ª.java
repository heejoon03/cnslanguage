import java.util.*;

public class MainClass 
{	
	//필요하다면 추가로 코드를 구현해 주세요.
	public static int solution(int seat1, int seat2)
	{
		int answer = 0;
		//코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args) 
	{
		int seat1 = 3;
		int seat2 = 6;
		int ret = solution(seat1, seat2);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}