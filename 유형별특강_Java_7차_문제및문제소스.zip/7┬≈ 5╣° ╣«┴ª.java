import java.util.*;

class Pair{
	public int x;
	public int y;
	public Pair(int x, int y) {
		this.x = x;
		this.y = y;
	}
}

public class MainClass {	
	public static int prisonerA = 0;
	public static int prisonerB = 0;

	public static ArrayList<ArrayList<Pair>> jail;

	public static boolean[] visit;
	public static int length = 0;

	public static void func_a(int[][] j,int n) {
		jail = new ArrayList<ArrayList<Pair>>();
		for(int i = 0; i <= n; i++)
			jail.add(new ArrayList<Pair>());

		for(int i = 0; i < j.length; i++){
			jail.get(j[i][0]).add(new Pair(j[i][1], j[i][2]));
			jail.get(j[i][1]).add(new Pair(j[i][0], j[i][2]));
		}
	}

	public static int func_b(int a, int b){
		return Math.max(a, b);
    }

	public static void func_c(int j, int t, int m)
    {
		if(j == prisonerB)
			length = t - m;
		if(length != 0)
			return;

		visit[j] = true;
		for (int i = 0; i < jail.get(j).size(); i++)
			if (visit[jail.get(j).get(i).x] == false)
				func_@@@(@@@);
	}
	
	public static int solution(int a, int b, int n, int[][] jail){
		int answer = 0;
		prisonerA = a;
		prisonerB = b;
		visit = new boolean[n+1];
		func_@@@(@@@);
		func_@@@(@@@);
		answer = length;
		return answer;
	}
	
	public static void main(String[] args) {
		int a = 1;
		int b = 9;
		int n = 9;
		int[][] jail = new int[8][];
		jail[0] = new int[] { 1, 2, 8 };
		jail[1] = new int[] { 2, 3, 6 };
		jail[2] = new int[] { 2, 4, 5 };
		jail[3] = new int[] { 2, 5, 10 };
		jail[4] = new int[] { 9, 5, 6 };
		jail[5] = new int[] { 6, 5, 14 };
		jail[6] = new int[] { 6, 7, 7 };
		jail[7] = new int[] { 8, 6, 7 };
		int ret = solution(a, b, n, jail);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}