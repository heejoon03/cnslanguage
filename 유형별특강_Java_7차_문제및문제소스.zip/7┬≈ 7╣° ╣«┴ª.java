import java.util.*;

public class MainClass
{	
	//추가적인 부분이 필요하다면 구현해 주세요.
	public static int[] solution(int[] coins, int price){
		int[] answer = null;	
		//코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args){	
		int[] coins = {4, 5, 2, 6, 3, 4};
		int price = 13;
		int[] ret = solution(coins, price);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}