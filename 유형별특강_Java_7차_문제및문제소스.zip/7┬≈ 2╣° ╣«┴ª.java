import java.util.*;

public class MainClass {	
	public static int[] solution(String[] sentence){
		int[] answer = new int[sentence.length];
		String temp = "";
        for (int i = 0; i < answer.length; i++){
            int findNotEqual = 0;
            for (findNotEqual = 0; findNotEqual < sentence[i].length() / 2; findNotEqual++)
                if (sentence[i].charAt(findNotEqual) != sentence[i].charAt(sentence[i].length() - 1 - findNotEqual))
                    break;
            
            if (findNotEqual != sentence[i].length()){
                temp = "";
                for (int k = 0; k < sentence[i].length(); k++)
                    if (k != findNotEqual)
                        temp += sentence[i].charAt(k);
                int checkIndex = 0;
                for (checkIndex = 0; checkIndex < temp.length(); checkIndex++)
                    if (temp.charAt(checkIndex) != temp.charAt(temp.length() - 1 - checkIndex))
                        break;

                if (checkIndex == temp.length()){
                    answer[i] = 1;
                    continue;
                }

                temp = "";
                for (int k = 0; k < sentence[i].length(); k++)
                    if (k != sentence[i].length() - 1 - findNotEqual)
                        temp += sentence[i].charAt(k);

                checkIndex = 0;
                for (checkIndex = 0; checkIndex < temp.length(); checkIndex++)
                    if (temp.charAt(checkIndex) != temp.charAt(temp.length() - 1 - checkIndex))
                        break;

                if (checkIndex == temp.length())
                    answer[i] = 1;
                else
                    answer[i] = 2;
            }
            else
                answer[i] = 0;
        }

        return answer;
	}
	
	public static void main(String[] args) {
		String[] sentence = {"ada", "summuus", "cavva", "cavvat", "oleole", "comwwmoc", "comwwtmoc"};
		int[] ret = solution(sentence);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}