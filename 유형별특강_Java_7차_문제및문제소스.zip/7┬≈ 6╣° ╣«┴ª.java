import java.util.*;

public class MainClass 
{	
	public static boolean[] solution(int k, int[][] result)
	{
		boolean[] answer = new boolean[result.length];
		int index = 0;
		for(int i = 0; i < result.length; i++)
        {
			int restRound = k - Math.max(result[i][0], result[i][1]);
			if(result[i][0] >= result[i][1] && @@@)
				answer[index++] = false;
			else if(result[i][0] < result[i][1] && @@@)
				answer[index++] = false;
			else
				answer[index++] = true;
        }

		return answer;
	}
	
	public static void main(String[] args) 
	{
		int k = 5;
		int[][] result = new int[4][];
		result[0] = new int[] {5, 5};
		result[1] = new int[] {5, 1};
		result[2] = new int[] {0, 3};
		result[3] = new int[] {1, 4};
		boolean[] ret = solution(k, result);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}







