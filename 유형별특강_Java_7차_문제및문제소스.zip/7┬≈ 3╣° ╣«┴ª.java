import java.util.*;

public class MainClass {	
	public static boolean[] solution(int[][] town, int[][] relation){
		boolean[] answer = new boolean[relation.length];
		int[] group = new int[10010];
		
		Arrays.sort(town, new Comparator<int[]>() {
			public int compare(int[] o1, int[] o2) {
				return Integer.compare(o1[0], o2[0]);
			}
		});

		int endX = town[0][1];
		int groupNum = 1;
		group[town[0][2]] = 1;

		for(int i = 1; i < town.length; i++){
			if(town[i][0] < endX){
				group[town[i][2]] = groupNum;
				endX = Math.max(endX, town[i][1]);
            }
			else{
				group[town[i][2]] = ++groupNum;
				endX = town[i][1];
            }
        }

		for(int i = 0; i < relation.length; i++)
			answer[i] = group[relation[i][0]] == group[relation[i][1]];

		return answer;
	}
	
	public static void main(String[] args) {
		int[][] town = new int[4][];
		town[0] = new int[] { 1, 5, 2};
		town[1] = new int[] { 3, 7, 4};
		town[2] = new int[] { 7, 9, 1};
		town[3] = new int[] {10, 13, 3};
		int[][] relation = { { 1, 3 }, { 1, 4 } };
		boolean[] ret = solution(town, relation);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}