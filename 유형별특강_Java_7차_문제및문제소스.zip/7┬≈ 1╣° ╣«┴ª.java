import java.util.*;

class Tree{
	public int[] dp = new int[300010];
	public ArrayList<Integer> v[];
	public int num = 0;
	public int result = 0;

	public Tree(int[][] tree, int cnt){
		num = cnt;
		v = new ArrayList[300010];
		for (int i = 0; i < 300010; i++)
			v[i] = new ArrayList<Integer>();
		for (int i = 0; i < num - 1; i++){
			v[tree[i][0]].add(tree[i][1]); 
			v[tree[i][1]].add(tree[i][0]);
		}
	}

	public int Combination(int n){
		return n * (n - 1) / 2;
	}

	public int Search(int current){
		dp[current] = 1;
		for(int e : v[current])
			if (dp[e] == 0)
				dp[current] += Search(e);
		result += Combination(num) - Combination(num - dp[current]);
		return dp[current];
	}
}

public class MainClass {	
	public static long solution(int[][] tree, int cnt){
		int answer = 0;
		Tree t = new Tree(tree, cnt);
		t.Search(1); 
		answer = t.result;
		return answer;
	}
	
	public static void main(String[] args) {
		int[][] tree1 = { { 1, 3 }, { 2, 3 } };
		int cnt1 = 3;
		long ret1 = solution(tree1, cnt1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		int[][]  tree2 = { { 6, 2 }, { 7, 5 }, { 3, 4 }, { 5, 6 }, { 1, 5 }, { 4, 1 }, { 8, 6 } };
		int cnt2 = 8;
		long ret2 = solution(tree2, cnt2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}