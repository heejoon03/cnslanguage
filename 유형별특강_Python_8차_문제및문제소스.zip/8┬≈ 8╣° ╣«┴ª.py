#추가적으로 필요한 코드는 이곳에 작성해 주세요.

def solution(card):
    answer = 0
    #코드를 구현해 주세요
    return answer

card1 = "27123"
card2 = "77777777777777777"

ret1 = solution(card1)
ret2 = solution(card2)
print("solution 함수의 return 값은",ret1,"입니다.")
print("solution 함수의 return 값은",ret2,"입니다.")