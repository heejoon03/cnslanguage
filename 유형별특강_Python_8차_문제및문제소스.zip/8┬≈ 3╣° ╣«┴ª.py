alpha = []

def search(before, pos, s):
    cnt = 0
    if pos == len(s):
        cnt += 1
    else :
        for i in range(26):
            if alpha[i] >= 1 and chr(ord('A')+i) != before:
                alpha[i] -= 1
                search(chr(ord('A')+i), pos + 1, s)
                alpha[i] += 1
    return cnt

def solution(s):
    answer = 0
    alpha.clear()
    for i in range(26):
        alpha.append(0)
    for e in s:
        alpha[ord(e)-ord('A')] += 1
    answer = search(0,0,s)
    return answer

s1 = "AB"
ret1 = solution(s1)
print("solution 함수의 return 값은",ret1,"입니다.")

s2 = "AAAB"
ret2 = solution(s2)
print("solution 함수의 return 값은",ret2,"입니다.")

s3 = "AABBBAA"
ret3 = solution(s3)
print("solution 함수의 return 값은",ret3,"입니다.")

s4 = "ABCDEFG"
ret4 = solution(s4)
print("solution 함수의 return 값은",ret4,"입니다.")