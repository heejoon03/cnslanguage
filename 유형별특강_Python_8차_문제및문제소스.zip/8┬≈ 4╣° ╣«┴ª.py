def solution(sequence):
    answer = 0
    s = []
    sequence.insert(0,0)
    s.append(0)
    for i in range(1,len(sequence)):
        while len(s) != 0 and @@@:
            temp = s[len(s)-1]
            s.pop(len(s)-1)
            answer = max(answer, sequence[temp] * @@@)
        s.append(i)
    return answer

sequence = [2, 1, 4, 5, 1, 3, 3]
ret = solution(sequence)
print("solution 함수의 return 값은",ret,"입니다.")