#추가적으로 필요한 코드는 이곳에 작성해 주세요.

def solution(price, atm):
    answer = 0
    #코드를 구현해 주세요
    return answer

price = 20
atm = [[5, 3], [10, 2], [1, 5]]
ret = solution(price, atm)
print("solution 함수의 return 값은",ret,"입니다.")