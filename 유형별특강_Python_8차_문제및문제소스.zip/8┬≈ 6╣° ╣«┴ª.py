class Edge:
    def __init__(self, n1, n2, distance):
        self.n1 = n1
        self.n2 = n2
        self.distance = distance

sets = []

def func_a(x):
    if sets[x] == x:
        return x
    sets[x] = func_@@@(@@@)
    return sets[x]

def func_b(a, b):
    a = func_@@@(@@@)
    b = func_@@@(@@@)
    return a == b

def func_c(a, b):
    a = func_@@@(@@@)
    b = func_@@@(@@@)
    if a < b:
        sets[b] = a
    else :
        sets[a] = b

def solution(tree):
    answer = 0
    v = []
    for i in range(len(tree)):
        for j in range(len(tree)):
            v.append(Edge(i,j,tree[i][j]))
    v.sort(key = lambda x : x.distance)
    for i in range(len(tree)):
        sets.append(i)
    for i in range(len(v)):
        if not func_@@@(@@@):
            answer += v[i].distance
            func_@@@(@@@)
    return answer

tree = [[0, 5, 10, 8, 7], [5, 0, 5, 3, 6], [10, 5, 0, 1, 3], [8, 3, 1, 0, 1] ,[7, 6, 3, 1, 0]]
ret = solution(tree)
print("solution 함수의 return 값은",ret,"입니다.")