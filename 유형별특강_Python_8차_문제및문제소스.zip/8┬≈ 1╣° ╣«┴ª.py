def heapify(heapIndex, endIndex, s):
    left = 2 * heapIndex
    right = 2 * heapIndex + 1
    large = 0
    if right <= endIndex:
        large = left if s[left] > s[right] else right
    elif left <= endIndex:
        large = left
    else:
        return
    if s[large] > s[heapIndex]:
        s[large], s[heapIndex] = s[heapIndex], s[large]
        heapify(large, endIndex, s)

def build(endIndex, s):
    for i in range(endIndex//2, 0, -1):
        heapify(i, endIndex, s)

def Sort(endIndex, s):
    build(endIndex, s)
    for i in range(endIndex, 0, -1):
        s[0],s[i] = s[i], s[0]
        heapify(0, i, s)
    return s

def solution(sequence):
    answer = []
    endIndex = len(sequence)
    sequence.insert(0,0) 
    answer = Sort(endIndex, sequence)
    answer.pop(len(answer)-1)
    return answer

sequence = [3, 6, 4, 8, 9, 7]
ret = solution(sequence)
print("solution 함수의 return 값은",ret,"입니다.")