rowDir = [-1, 0 , 1, 0]
colDir = [0, -1, 0, 1]
def search(r, c, m, a, b, v, result):
    result.append(m)
    for i in range(4):
        nextRow = r + rowDir[i]
        nextCol = c + colDir[i]
        if 0 <= nextRow < len(b) and 0 <= nextCol < len(b[0]):
            if v[nextRow][nextCol] == 0:
                if a[ord(b[nextRow][nextCol]) - ord('A')] == 0:
                    v[nextRow][nextCol] = 1
                    a[ord(b[nextRow][nextCol]) - ord('A')] += 1
                    search(nextRow, nextCol, m+1, a, b, v, result)
                    a[ord(b[nextRow][nextCol]) - ord('A')] += 1
                    v[nextRow][nextCol] = 0
def solution(board):
    answer = 0
    alphabet = [0]*26
    alphabet[ord(board[0][0])-ord('A')] += 1
    visited = []
    result = []
    for i in range(len(board)):
        visited.append([0] * len(board[0]))
    visited[0][0] = 1
    search(0,0,1,alphabet, board, visited, result)
    answer = max(result)
    return answer

board1 = ["CAAB", "ADCB"]
ret1 = solution(board1)
print("solution 함수의 return 값은",ret1,"입니다.")

board2 = ["HFDFFB", "AJHGDH", "DGAGEH"]
ret2 = solution(board2)
print("solution 함수의 return 값은",ret2,"입니다.")

board3 = ["IEFCJ", "FHFKC", "FFALF", "HFGCF", "HMCHH"]
ret3 = solution(board3)
print("solution 함수의 return 값은",ret3,"입니다.")