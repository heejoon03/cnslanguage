class Vaccine:
    def __init__(self,vaccines):
        pass
    def Create(self):
        pass
    def Inoculate(self):
        pass

class Manssen(Vaccine):
    def __init__(self, vaccines):
        self.vaccineCnt = 0
        self.total = 0
        for e in vaccines:
            if e[0:e.find('-')] == "Manssen":
                self.vaccineCnt = @@@
                break
    def Create(self):
        for i in range(1, self.vaccineCnt+1):
            if @@@
                continue
            else:
                self.total+=1
    def Inoculate(self):
        danger = 0
        for i in range(1, self.total+1):
            if @@@
                danger += 1
        return @@@

class Mfizer(Vaccine):
    def __init__(self, vaccines):
        self.vaccineCnt = 0
        self.total = 0
        for e in vaccines:
            if e[0:e.find('-')] == "Mfizer":
                self.vaccineCnt = @@@
                break
    def Create(self):
        for i in range(1, self.vaccineCnt+1):
            if @@@
                continue
            else:
                self.total+=1
    def Inoculate(self):
        danger = 0
        for i in range(1, self.total+1):
            if @@@
                danger += 1
        return @@@

class Minovac(Vaccine):
    def __init__(self, vaccines):
        self.vaccineCnt = 0
        self.total = 0
        for e in vaccines:
            if e[0:e.find('-')] == "Minovac":
                self.vaccineCnt = @@@
                break
    def Create(self):
        bad = 0
        for i in range(1, self.vaccineCnt+1):
            if @@@:
                bad += 1
                continue
            else:
                self.total+=1
        @@@
    def Inoculate(self):
        danger = 0
        nest = 1
        for i in range(1, self.total+1):
            if @@@
                danger += nest
                @@@
        return @@@

def solution(vaccines):
    answer = []
    vaccineInfo = []
    vaccineInfo.append(Manssen(vaccines))
    vaccineInfo.append(Mfizer(vaccines))
    vaccineInfo.append(Minovac(vaccines))

    for e in vaccineInfo:
        e.Create()
        answer.append(e.Inoculate())
    
    return answer

vaccines = ["Manssen-100", "Mfizer-200", "Minovac-300"]
ret = solution(vaccines)
print("solution 함수의 return 값은",ret,"입니다.")