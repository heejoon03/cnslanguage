using System;
using System.Collections.Generic;

class MainClass
{
	public static string func_a(string s1, string[] s2, int n){
		List<string> ret = new List<string>();
		for(int i = 0; i < s1.Length; i++){
			string[] postfix = func_@@@(@@@);
			for(int j = 0; j < postfix.Length; j++)
				ret.Add(postfix[j]);
        }
		ret.Sort();
		return ret[n-1];
    }

	public static string[] func_b(string s){
		string[] ret = new string[s.Length];
		for(int i = 0; i < s.Length; i++)
			ret[i] = s.Substring(0, i + 1);
		return ret;
	}

	public static string[] func_c(string s){
		string[] ret = new string[s.Length];
		for(int i = 0; i < s.Length; i++)
			ret[i] = s.Substring(i);
		return ret;
	}
	

	public static string solution(string text, int n){
		string[] prefix = func_@@@(@@@);
		string answer = func_@@@(@@@);
        return answer;
	}

	public static void Main(string[] args){
		string text1 = "cat";
		int n1 = 4;
		string ret1 = solution(text1, n1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		
		string text2 = "LGCNS";
		int n2 = 9;
		string ret2 = solution(text2, n2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}