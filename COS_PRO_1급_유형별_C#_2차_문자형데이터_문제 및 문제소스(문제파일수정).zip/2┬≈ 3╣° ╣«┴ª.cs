using System;
using System.Collections.Generic;
using System.Linq;

class Pair
{
	public int x;
	public int y;

	public Pair(int x, int y)
    {
		this.x = x;
		this.y = y;
    }

	public bool IsContain(List<Pair> l)
    {
        foreach (var e in l)
        {
            if (e.x == x && e.y == y)
            {
                return true;
            }
            else if (e.x == y && e.y == x)
            {
				return true;
            }
        }

        return false;
    }
}
class MainClass
{
	public static string solution(string[] coefficient)
	{
		string answer = "";

		int f = int.Parse(coefficient[0]);
		int s = int.Parse(coefficient[1]);
		int t = int.Parse(coefficient[2]);

		List<Pair> fPair = new List<Pair>();
		List<Pair> tPair = new List<Pair>();
		List<char> r = new List<char>();
		int[] ft = { f, t };

		for(int i = 0; i < ft.Length; i++)
        {
			for (int j = Math.Abs(ft[i]) * -1; j <= Math.Abs(ft[i]); j++)
			{
				for (int k = ft[i] * -1; k <= j; k++)
				{
					if (j * k == ft[i] && i == 0)
					{
						Pair temp = new Pair(j, k);
						if(!temp.IsContain(fPair))
                        {
							fPair.Add(temp);
						}
					}
					else if(j * k == ft[i] && i == 1)
                    {
						Pair temp = new Pair(j, k);
						if(!temp.IsContain(tPair))
                        {
							tPair.Add(temp);
						}
					}
				}
			}
		}

		foreach(Pair e1 in fPair)
        {
			foreach(Pair e2 in tPair)
            {
				if(e1.x * e2.y + e1.y * e2.x == s)
                {
					string temp = "(" + e1.x + " " + e2.x + ")" + "(" + e1.y + " " + e2.y + "),";
					foreach(char e in temp)
                    {
						r.Add(e);
                    }
                }
            }
        }

		for(int i = 0; i < r.Count; i++)
        {
			if(r[i] == ' ')
            {
				continue;
            }
			else if (r[i] == '1')
			{
				r[i] = 'x';
				answer += r[i];
			}
			else if(r[i] > '1' && r[i] <= '9')
            {
				if(r[i-1] == '-')
                {
					answer += r[i];
				}
				else
                {
					answer += '+';
					answer += r[i];
				}
			}
			else
            {
				answer += r[i];
			}
		}

		if(answer.Length > 0)
        {
			answer = answer.Substring(0, answer.Length - 1);
		}
		else
        {
			answer = "Nope";
        }
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] coefficient1 = {"+1","-1","-6"};
		string ret1 = solution(coefficient1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string[] coefficient2 = { "+2", "+1", "+6" };
		string ret2 = solution(coefficient2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
