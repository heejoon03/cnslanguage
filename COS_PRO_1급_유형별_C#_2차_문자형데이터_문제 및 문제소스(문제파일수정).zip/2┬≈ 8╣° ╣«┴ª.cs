using System;

class MainClass
{
	public static int solution(string str)
	{
		int answer = 0;
		//이곳을 구현해 주세요.
        return answer;
	}

	public static void Main(string[] args)
	{
		string str1 = "((((";
		int ret1 = solution(str1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string str2 = "()()()))(";
		int ret2 = solution(str2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
