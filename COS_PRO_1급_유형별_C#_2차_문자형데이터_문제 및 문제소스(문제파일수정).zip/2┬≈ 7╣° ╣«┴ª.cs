using System;
using System.Collections.Generic;

class MainClass
{
	public static string solution(string[] str)
	{
		string answer = "";

		//이곳을 구현해 주세요.

        return answer;
	}

	public static void Main(string[] args)
	{
		string[] str1 = {"ABCDE","abcde","01234","FGHIJ","fghij"};
		string ret1 = solution(str1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string[] str2 = { "AABCDD", "afzz", "09121", "a8EWg6", "P5h3kx" };
		string ret2 = solution(str2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}





































