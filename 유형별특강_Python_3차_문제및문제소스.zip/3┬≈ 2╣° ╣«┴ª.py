def solution(str):
	answer = 0
	
	s = list()
	temp = 1

	for i in range(len(str)):
		if str[i] == '(':
			temp *= 2
			s.append('(')
		elif str[i] == '[':
			temp *= 3
			s.append('[')
		elif str[i] == ')' and or str[i] == ']' :
			answer = -1
			break
		elif str[i] == ')':
			if str[i-1] == '(':
				answer += temp
			s.pop()
			temp //= 2
		elif str[i] == ']':
			if str[i-1] == '[':
				answer += temp
			s.pop()
			temp //= 3

	return answer


str1 = "(()[[]])([])";
ret1 = solution(str1);
print("solution 함수의 반환 값은 ", ret1, " 입니다.");

str2 = "[(]]";
ret2 = solution(str2);
print("solution 함수의 반환 값은 ", ret2 , " 입니다.");