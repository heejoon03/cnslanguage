def solution(text, n):
	prefix = []
	for i in range(len(text)):
		prefix.append(text[:i+1])

	answer = []
	for i in range(len(text)):
		postfix = []
		for j in range(len(prefix[i])):
			postfix.append(postfix[j][-j:])
		for p in postfix:
			answer.append(p)
	answer.sort()
	answer = answer[n-1]
	return answer


text1  = "cat";
n1 = 4
ret1 = solution(text1, n1);
print("solution 함수의 반환 값은", ret1, "입니다.");

text2  = "LGCNS";
n2 = 9
ret2 = solution(text2, n2);
print("solution 함수의 반환 값은", ret2, "입니다.");