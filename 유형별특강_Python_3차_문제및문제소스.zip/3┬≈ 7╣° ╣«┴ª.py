def func_a(arr):
	answer = -1
	for i in range(len(arr)):
		if answer == -1:
			answer = i
		elif arr[answer] < arr[i]:
			answer = i
	return answer

def func_b(arr1, arr2):
	answer = [0] * len(arr1)
	for i in range(len(arr1)):
		for j in range(len(arr2)):
			if arr1[i] == arr2[j]:
				answer[i] += 1
	return answer

def func_c(arr, number):
	answer = -1
	for i in range(len(arr)):
		if arr[i] == number:
			continue
		if answer == -1:
			answer = i
		elif arr[answer] < arr[i]:
			answer = i
	return answer

def solution(candidates, names):
	counter = func_@@@(@@@)
	first = func_@@@(@@@)
	second = func_@@@(@@@)
	answer = [candidates[first], candidates[second]]
	return answer


candidates = ["Anna", "Elsa", "Olaf"]
names = ["Anna", "Elsa", "Olaf","Hans", "Anna", "Elsa", "Elsa", "Bobuncle"]
ret = solution(candidates, names);
print("solution 함수의 반환 값은 ", ret, " 입니다.");
