class Pair:
	def __init__(self, x, y):
		self.x = x
		self.y = y
	def isContain(self, l):
		for e in l:
			if e.x == self.x and e.y == self.y:
				return True
			elif e.x == self.y and e.y == self.x:
				return True
		return False


def solution(coefficient):
	answer = ""
	
	f = int(coefficient[0])
	s = int(coefficient[1])
	t = int(coefficient[2])

	fPair = list()
	tPair = list()
	r = list()
	ft = [f,t]

	for i in range(len(ft)):
		for j in range (abs(ft[i]) * -1, abs(ft[i]) + 1):
			for k in range (ft[i] * -1, j + 1)):
				if j * k == ft[i] and i == 0:
					temp = Pair(j,k)
					if temp.isContain(fPair) == False:
						fPair.append(temp)
				elif j * k == ft[i] and i == 1:
					temp = Pair(j,k)
					if temp.isContain(tPair) == False:
						tPair.append(temp)
						
	for e1 in fPair:
		for e2 in tPair :
			if e1.x * e2.y + e1.y * e2.x == s:
				t = '(' + str(e1.x) + ' ' + str(e2.x) + ')' + '(' + str(e1.y) + ' ' + str(e2.y) + '),'
				for i in range(len(t)):
					r.append(t[i])

	for i in range(len(r)):
		if r[i] == ' ':
			continue
		elif r[i] == '1':
			r[i] = 'x'
			answer += r[i]
		elif r[i] == r[i] > '1' and r[i] <= '9':
			if r[i-1] == '-':
				answer += r[i]
			else :
				answer += '+'
				answer += r[i]
		else :
			answer += r[i]

	if len(answer) > 0:
		answer = answer[:len(answer)-1] #마지막 문자 쉼표(,) 제거
	else:
		answer = "Nope"

	return answer


coefficient1  = ["+1","-1","-6"];
ret1 = solution(coefficient1);
print("solution 함수의 반환 값은 ", ret1, " 입니다.");

coefficient2 = ["+2", "+1", "+6" ];
ret2 = solution(coefficient2);
print("solution 함수의 반환 값은 ", ret2 , " 입니다.");
