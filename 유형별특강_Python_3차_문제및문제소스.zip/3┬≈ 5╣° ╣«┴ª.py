def solution(str):
	answer = ""
	chs = []
	for i in range(5):
		chs.append([""]*15)
	for i in range(len(str)):
		for j in range(len(str[i])):
			chs[i][j] = str[i][j]
	for i in range(15):
		for j in range(5):
			if chs[j][i] == ' ':
				answer += chs[j][i]
	return answer


str1 = ["ABCDE","abcde","01234","FGHIJ","fghij"]
ret1 = solution(str1);
print("solution 함수의 반환 값은 ", ret1, " 입니다.");

str2 = ["AABCDD", "afzz", "09121", "a8EWg6", "P5h3kx"]
ret2 = solution(str2);
print("solution 함수의 반환 값은 ", ret2, " 입니다.");
