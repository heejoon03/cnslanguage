def solution(str, find):
	answer = 0
	for i in range(len(str)):
		cnt = 0
		index = i
		for j in range(len(find)):
			if str[index] == find[j]:
				cnt += 1
			index += 1
		if cnt == len(find):
			answer += 1
	return answer


str1 = "HOIOIOIOI";
find1 = "IOI";
ret1 = solution(str1, find1);
print("solution 함수의 반환 값은 ", ret1, " 입니다.");

str2 = "MYLEVELEVELEVELEVEL";
find2 = "LEVEL";
ret2 = solution(str2, find2);
print("solution 함수의 반환 값은 ", ret2 , " 입니다.");