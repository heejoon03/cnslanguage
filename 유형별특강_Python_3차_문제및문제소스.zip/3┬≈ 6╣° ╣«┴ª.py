def func_a(arr):
	answer = []
	for i in range(len(arr)):
		answer.append(arr[i] // 5)
	return answer

def func_b(arr):
	answer = 0
	for i in range(len(arr)):
		answer += arr[i]
	return answer

def func_c(arr):
	answer = []
	number1 = 0
	number2 = 0
	begin = 0
	end = 0
	for i in range(len(arr)):
		number1 = 10 * int(arr[i][0]) + int(arr[i][1])
		number2 = 10 * int(arr[i][3]) + int(arr[i][4])
		begin = 60 * number1 + number2
		number1 = 10 * int(arr[i][6]) + int(arr[i][7])
		number2 = 10 * int(arr[i][9]) + int(arr[i][10])
		end = 60 * number1 + number2;
		answer.append(end - begin);
	return answer

def solution(timetable):
	answer = 0
	time = func_@@@(@@@)
	count = func_@@@(@@@)
	answer = func_@@@(@@@)
	return answer


timetable  = ["10:06~10:40", "11:34~12:00"]
ret = solution(timetable);
print("solution 함수의 반환 값은 ", ret, " 입니다.");
