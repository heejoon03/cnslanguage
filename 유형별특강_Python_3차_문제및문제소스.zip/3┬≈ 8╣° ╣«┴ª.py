def solution(str):
	answer = 0
	#여기를 구현해 주세요.
	return answer


str1 = "(((("
ret1 = solution(str1);
print("solution 함수의 반환 값은 ", ret1, " 입니다.");

str2 = "()()()))("
ret2 = solution(str2);
print("solution 함수의 반환 값은 ", ret2, " 입니다.");
