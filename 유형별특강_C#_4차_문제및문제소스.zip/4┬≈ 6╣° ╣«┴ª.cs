using System;
using System.Collections.Generic;
using System.Linq;

public class MainClass {
	public static bool[] solution(int k, int[][] result)
	{
		bool[] answer = new bool[result.GetLength(0)];
		int index = 0;
		for(int i = 0; i < result.GetLength(0); i++)
        {
			int restRound = k - Math.Max(result[i][0], result[i][1]);
			if(result[i][0] >= result[i][1] && @@@)
            {
				answer[index++] = false;
            }
			else if(result[i][0] < result[i][1] && @@@)
            {
				answer[index++] = false;
            }
			else
            {
				answer[index++] = true;
            }
        }

		return answer;
	}

	public static void Main(string[] args){

		int k = 5;
		int[][] result = new int[4][];
		result[0] = new int[] {5, 5};
		result[1] = new int[] {5, 1};
		result[2] = new int[] {0, 3};
		result[3] = new int[] {1, 4};
		bool[] ret = solution(k, result);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",", ret) + "] 입니다.");
	}
}
