using System;
using System.Collections.Generic;
using System.Linq;

public class MainClass {
	public static int[] solution(char[] card)
	{
		int[] answer = new int[card.Length];
		//코드를 구현해 주세요.
		return answer;
	}

	public static void Main(string[] args){

		char[] card = { 'a', 'r', 'd', 'e', 'w' };
		int[] ret = solution(card);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",", ret) + "] 입니다.");
	}
}
