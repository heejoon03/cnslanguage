using System;
using System.Collections.Generic;
using System.Linq;

public class MainClass {
	public static int func_a(string[] s,int r, int c)
	{
		return s[r][c] - '0';
	}
	public static int[][] func_b(string[] c)
    {
		int[][] ret = new int[9][];
		for(int i = 0; i < 9; i++)
        {
			ret[i] = new int[5];
        }

		for (int j = 0; j < c.Length; j++)
		{
			int begin = func_@@@(@@@) * 10 + func_@@@(@@@);
			int end = func_@@@(@@@) * 10 + func_@@@(@@@);
			int time = end - begin;
			int startTimeIndex = func_a(c, j, 0) * 10 + func_a(c, j, 1) - 13;
			for (int k = 0; k < time; k++)
			{
				ret[startTimeIndex++][func_@@@(@@@)] = 1;
			}
		}

		return ret;
    }
	public static bool func_c(int[] c)
    {
		int cnt = 0;
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i] == 1)
			{
				cnt++;
			}
		}
		return cnt >= 5;
	}

	public static bool solution(string[] calendar)
	{
		bool answer = false;
		int[][] arr = func_@@@(@@@);
		for (int i = 0; i < arr.GetLength(0); i++)
        {
			if(func_@@@(@@@))
            {
				answer = true;
				return answer;
            }
        }
		return answer;
	}

	public static void Main(string[] args){
		string[] calendar = {"13~15:0", "14~15:1", "14~15:2", "13~15:3",
							 "14~15:4", "15~16:0" ,"16~17:0", "16~17:1",
							 "16~17:2","16~17:3", "16~17:4", "17~18:2",
							 "18~19:2"};
		bool ret = solution(calendar);
		Console.WriteLine("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
