using System;
using System.Collections.Generic;

public class MainClass
{
	public static int[] solution(string[] sentence)
	{
		int[] answer = new int[sentence.Length];
        string temp = "";
        for (int i = 0; i < answer.Length; i++){
            int findNotEqual = 0;
            for (findNotEqual = 0; findNotEqual < sentence[i].Length / 2; findNotEqual++){
                if (sentence[i][findNotEqual] != sentence[i][sentence[i].Length - 1 - findNotEqual]){
                    break;
                }
            }

            if (findNotEqual != sentence[i].Length){
                temp = "";
                for (int k = 0; k < sentence[i].Length; k++){
                    if (k != findNotEqual){
                        temp += sentence[i][k];
                    }
                }

                int checkIndex = 0;
                for (checkIndex = 0; checkIndex < temp.Length; checkIndex++){
                    if (temp[checkIndex] != temp[temp.Length - 1 - checkIndex]){
                        break;
                    }
                }

                if (checkIndex == temp.Length){
                    answer[i] = 1;
                    continue;
                }

                temp = "";
                for (int k = 0; k < sentence[i].Length; k++){
                    if (k != sentence[i].Length - 1 - findNotEqual){
                        temp += sentence[i][k];
                    }
                }

                checkIndex = 0;
                for (checkIndex = 0; checkIndex < temp.Length; checkIndex++){
                    if (temp[checkIndex] != temp[temp.Length - 1 - checkIndex]){
                        break;
                    }
                }

                if (checkIndex == temp.Length){
                    answer[i] = 1;
                }
                else{
                    answer[i] = 2;
                }
            }
            else{
                answer[i] = 0;
            }
        }

        return answer;
	}

	public static void Main(string[] args)
	{
		string[] sentence = {"ada", "summuus", "cavva", "cavvat", "oleole", "comwwmoc", "comwwtmoc"};
		int[] ret = solution(sentence);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",", ret) + "] 입니다.");
	}
}
