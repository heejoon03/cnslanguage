class Solution:
	def __init__(self):
		self.cnt = 0
		self.visit = []
		self.ani = []
		self.rowDir = [0,1,0,-1]
		self.colDir = [-1,0,1,0]

	def search(self, r, c):
		self.visit[r][c] = True
		for i in range(4):
			nextRow = r + self.rowDir[i]
			nextCol = c + self.colDir[i]
			if nextRow >= 0 and nextCol >= 0:
				if nextRow < 7 and nextCol < 7:
					if self.visit[nextRow][nextCol] == False:
						if self.ani[nextRow][nextCol] == self.ani[r][c]:
							self.cnt += 1
							self.visit[nextRow][nextCol] = True
							self.search(nextRow, nextCol)

def solution(anipang):
	answer = 0
	sol = Solution()

	for i in range(7):
		sol.visit.append([False] * 7)
	sol.ani = anipang

	for i in range(7):
		for j in range(7):
			sol.search(i,j)
			if sol.cnt == 3:
				answer += 1
			sol.cnt = 0

	return answer


anipang = ["MCBRAPC", "MMROPPO", "BBCCAMB", "APMPORA", "BMACOMB", "RPOAORP", "MOPMPBB"];
ret = solution(anipang)
print("solution 메소드의 반환 값은", ret, "입니다.");
