class Solution:
	def __init__(self):
		self.str = ""
		self.length = 0
		self.visit = [False] * 10
		self.temp = []

	def search(self, v, c, s):
		if c == self.length:
			self.temp.append(s)
		else:
			for i in range(10):
				if self.visit[i] == False:
					if self.str[c] == '<':
						if v >= i :
							continue
					else :
						if v <= i :
							continue
					self.visit[i] = True
					self.search(i+1, c + 1, s + str(i+1)) 
		self.visit[v] = False

def solution(A):
	answer = []
	sol = Solution()

	sol.length = len(A)
	sol.str = A

	for i in range(10):
		sol.visit[i] = True
		sol.search(i, 0, str(i)+"")

	answer.append(sol.temp[len(sol.temp)-1])
	answer.append(sol.temp[0])

	return answer


A1 = "<>"
ret1 = solution(A1)
print("solution 메소드의 반환 값은", ret1, "입니다.");

A2 = "><<<>>><<"
ret2 = solution(A2)
print("solution 메소드의 반환 값은", ret2, "입니다.");
