def func_a(arr, s):
	for i in range(len(s)):
		if s[i] == 'W':
			arr[0] += 1
		else :
			arr[1] += 1

def func_b(s, b):
	answer = 0
	for i in range(len(s)-1, -1, -1):
		if s[i] == b:
			answer += 1
		else :
			break
	return answer

def func_c(s, b):
	answer = 0
	for i in range(0, len(s)):
		if s[i] == b:
			answer += 1
		else :
			break
	return answer

def solution(balls):
	answer = 500000
	check = [0] * 2

	func_@@@(@@@)

	case1 = func_@@@(@@@)
	case2 = func_@@@(@@@)
	case3 = func_@@@(@@@)
	case4 = func_@@@(@@@)

	if check[0] - case1 < answer:
		answer = check[0] - case1
	if check[0] - case2 < answer:
		answer = check[0] - case2
	if check[1] - case3 < answer:
		answer = check[1] - case3
	if check[1] - case4 < answer:
		answer = check[1] - case4
	return answer


balls1 = "WBBBWBWWW"
ret1 = solution(balls1)
print("solution 메소드의 반환 값은", ret1, "입니다.");

balls2 = "BBWBBBBW"
ret2 = solution(balls2)
print("solution 메소드의 반환 값은", ret2, "입니다.");
