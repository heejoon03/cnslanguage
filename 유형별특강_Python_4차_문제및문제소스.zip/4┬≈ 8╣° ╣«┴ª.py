def solution(extension, files):
	answer = 0
	#여기를 구현해 주세요.
	return answer


extension = "doc";
files = ["lg.doc", "lg.xls", "lgcns.doc", "lgcns.docx"]
ret = solution(extension, files);
print("solution 메소드의 반환 값은", ret, "입니다.");
