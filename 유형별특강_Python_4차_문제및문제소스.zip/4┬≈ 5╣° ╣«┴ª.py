def solution(stick):
	answer = 0
	
	cutLocation = 0
	cutStickCount = 0

	for i in range(len(stick)):
		if stick[i] == '(':
			cutLocation = @@@
			cutStickCount += @@@
		elif stick[i] == ')' and cutLocation == 1:
			cutStickCount -= @@@
			answer += @@@
			cutLocation = @@@
		elif stick[i] == ')' and cutLocation != 1:
			answer += @@@
			cutLocation = @@@
			cutStickCount -= @@@
	return answer


stick1 = "()(((()())(())()))(())"
ret1 = solution(stick1)
print("solution 메소드의 반환 값은", ret1, "입니다.");

stick2 = "(((()(()()))(())()))(()())"
ret2 = solution(stick2)
print("solution 메소드의 반환 값은", ret2, "입니다.");
