def solution(dice, coin):
	answer = 0
	#여기를 구현해 주세요.
	return answer


coin = "FFFBF";
dice = 5
ret = solution(dice, coin);
print("solution 메소드의 반환 값은", ret, "입니다.");
