from abc import*

class Attendance(metaclass = ABCMeta):
	@abstractclassmethod
	def record(time):
		pass
	@abstractclassmethod
	def check():
		pass

class Employee@@@:
	def __init__(self):
		@@@
	@@@:
		for i in range(len(attendance)):
			attHour = int(attendance[i][6] + attendance[i][7])
			enterHour = int(attendance[i][0] + attendance[i][1])
			enterMin = int(attendance[i][3] + attendance[i][4])

			if @@@:
				self.attendanceTime[attHour] += 1
			elif @@@:
				self.attendanceTime[attHour] += 1
	@@@:
		cnt = 0
		for i in range(len(self.attendanceTime)):
			@@@
		return @@@

class Executive@@@:
	def __init__(self):
		@@@
	def record(self, attendance):
		for i in range(len(attendance)):
			attHour = int(attendance[i][6] + attendance[i][7])
			enterHour = int(attendance[i][0] + attendance[i][1])
			enterMin = int(attendance[i][3] + attendance[i][4])

			if @@@:
				self.attendanceTime[attHour] += 1
			elif @@@:
				self.attendanceTime[attHour] += 1
	def check(self):
		cnt = 0
		for i in range(len(self.attendanceTime)):
			@@@
		return @@@

def solution(employee, executive):
	answer = []
	emplo = Employee()
	execu = Executive()

	emplo.record(employee)
	execu.record(executive)

	answer.append(emplo.check())
	answer.append(execu.check())
	return answer


employee = ["07:30_07", "08:20_08", "09:10_07", "08:10_07", "10:40_11", "10:20_08", "11:00_11", "11:20, 11", "07:50_08", "12:30_10"]
executive = ["08:10_07", "10:40_11", "10:20_08", "11:00_11", "10:30_10"]
ret = solution(employee, executive);
print("solution 메소드의 반환 값은", ret, "입니다.");
