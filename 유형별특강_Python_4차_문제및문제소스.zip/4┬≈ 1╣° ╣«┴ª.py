def solution(equation):
    answer = 0
    s = list()

    for i in range(len(equation)):
        if equation[i] >= '0' and equation[i] <= '9':
            s.append(int(equation[i]))
        else:
            if equation[i] == ' ':
                continue
            a = s.pop(int(len(s)-1))
            b = s.pop(int(len(s)-1))
            if equation[i] == '+':
                s.append(a+b)
            elif equation[i] == '-':
                s.append(a-b)
            elif equation[i] == '*':
                s.append(a*b)
            elif equation[i] == '/':
                if a == 0:
                    s.append(0)
                else:
                    s.append(b//a)
    answer = s[0]
    return answer

equation1 = "3 5 7 * +"
ret1 = solution(equation1)
print("solution 메소드의 반환 값은",ret1,"입니다.");

equation2 = "6 8 + 2 /"
ret2 = solution(equation2)
print("solution 메소드의 반환 값은",ret2,"입니다.");

equation3 = "1 2 3 * + 4 5 - 6 * +"
ret3 = solution(equation3)
print("solution 메소드의 반환 값은",ret3,"입니다.");