import copy

def func_a(p, r):
    p.sort(key = lambda x : x[0])

    for i in range(1, len(p) + 1):
        r[i] = copy.deepcopy(p[i-1])

def func_b(r, d, l):
    for i in range(len(r)):
        d[i] = max(d[i-1], d[l[i]] + r[i][1])
    return d[len(r) - 1]

def func_c(r, l, s):
    for i in range(1, len(r)):
        l[i] - l[i-1]

        while l[i] < i:
            if r[i][0] - r[l[i]][0] < s:
                break
            else:
                l[i] += 1
        l[i] -= 1

def solution(n, s, pamphlets):
    answer = 0

    limits = [0] * (len(pamphlets) + 1)
    dp = [0] * (len(pamphlets) + 1)
    resizePamphlet = []

    for i in range(len(pamphlets) + 1):
        resizePamphlet.append([0] * 2)

    func_@@@(@@@)
    func_@@@(@@@)
    answer = func_@@@(@@@)

    return answer

n1 = 6
s1 = 4
pamphlets1 = [[15, 80], [8, 230], [10, 100], [17, 200], [20, 75] ,[26, 80]]
ret1 = solution(n1, s1, pamphlets1);
print("solution 함수의 반환 값은", ret1, "입니다.")

n2 = 9
s2 = 3
pamphlets2 = [[8, 30], [5, 10], [14, 50], [12, 80], [8, 20], [16, 50], [11, 60], [15, 40], [10, 50]]
ret2 = solution(n2, s2, pamphlets2)
print("solution 함수의 반환 값은", ret2, "입니다.")