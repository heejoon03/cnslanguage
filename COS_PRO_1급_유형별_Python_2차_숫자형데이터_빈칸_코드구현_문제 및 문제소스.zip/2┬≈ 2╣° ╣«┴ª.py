class Virus:
	def __init__(self, row, col, count):
		self.row = row
		self.col = col
		self.count = count

def func_a(visit, grid, bfs, m, n):
	for i in range(n):
		visit.append([0] * m)
	for i in range(n):
		for j in range(m):
			if grid[i][j] == 1:
				bfs.append(Virus(i,j,0))
				visit[i][j] = 1
			elif grid[i][j] == -1:
				visit[i][j] = 1

def func_b(bfs, visit, rDir, cDir, result, m, n):
	a = bfs[0]
	bfs.pop(0)

	result = max(result, a.count)

	for i in range(4):
		nextRow = a.row + rDir[i]
		nextCol = a.col + cDir[i]
		if nextRow >= 0 and nextCol >= 0 and nextRow < n and nextCol < m :
			if visit[nextRow][nextCol] == 0:
				bfs.append(Virus(nextRow, nextCol, a.count + 1))
				visit[nextRow][nextCol] = 1

	return result

def func_c(visit, bfs, m, n):
	result = 0
	rowDir = [-1, 0, +1, 0]
	colDir = [0, +1, 0, -1]

	if len(bfs) == 0:
		result = -1
	else :
		while len(bfs) != 0:
			result = func_@@@(@@@)

		for i in range(n):
			for j in range(m):
				if visit[i][j] == 0:
					result = -1
	return result

def solution(m, n, grid):
	answer = 0
	
	visit = []
	bfs = list()

	func_@@@(@@@)
	answer = func_@@@(@@@)

	return answer

m = 6
n = 4
grid = [[0, 0, 0, 0, 0, 0,], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 1]]
ret = solution(m, n, grid)
print("solution 메소드의 반환 값은 ", ret , " 입니다.")