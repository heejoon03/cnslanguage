﻿
def solution(k, scores):
    answer = []
    #이곳을 구현해 주세요.
    return answer

k = 2
scores = [9.3, 9.5, 9.6, 9.8, 9.1, 5.0, 9.3]
ret = solution(k, scores)
print("solution 메소드의 반환 값은", ret, "입니다.")