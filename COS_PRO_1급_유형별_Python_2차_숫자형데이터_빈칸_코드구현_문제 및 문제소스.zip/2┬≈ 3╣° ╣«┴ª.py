from abc import*

class IDamageable(metaclass = ABCMeta):
	@abstractclassmethod
	def GetDamage():
		pass

	@abstractclassmethod
	def SetDamage(damage):
		pass

class Player@@@:
	def __init__(self, damage):
		self.damage = damage

	def @@@:
		return self.damage

	def @@@:
		self.damage = damage

class Fruit@@@:
	def __init__(self, damage):
		self.damage = damage

	def @@@:
		return self.damage

	def @@@:
		if damage > 0 :
			self.damage = damage * -1
		else :
			self.damage = damage


def solution(damage, recovery):
	answer = []
	
	player = Player(100)
	fruit = Fruit(-20)

	prevPlayerDamage = player.damage
	prevFruitRecovery = fruit.damage

	player.SetDamage(damage)
	fruit.SetDamage(recovery)

	answer.append(prevPlayerDamage < player.GetDamage())
	answer.append(recovery < 0)

	return answer


damage = 200
recovery = 30
ret = solution(damage, recovery)
print("solution 메소드의 반환 값은 ", ret , " 입니다.")