class Treasure:
    def __init__(self, row, col, length):
        self.row = row
        self.col = col
        self.length = length

def solution(row, col, grid):
    answer = 0
    #여기를 구현해 주세요.
    return answer

row = 5;
col = 7;
grid = [[1,0,0,1,1,1,0], 
	    [0,0,0,1,0,0,0], 
		[0,1,0,1,0,1,1], 
		[0,1,0,1,0,0,0], 
		[1,0,0,1,0,1,1]]

ret = solution(row, col, grid);	
print("solution 메소드의 반환 값은", ret, "입니다.")