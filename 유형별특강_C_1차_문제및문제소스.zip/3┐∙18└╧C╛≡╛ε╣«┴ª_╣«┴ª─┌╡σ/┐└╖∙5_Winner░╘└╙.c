#include <stdio.h>
#include <stdlib.h>


int solution(int card) {
	int answer = 0;
	int numcnt[10] = { 0, };
	int v1, i;
	int tri = 0;
	int run = 0;
	
	while (card >= 0) {
		v1 = card % 10;
		card /= 10;

		numcnt[v1]++;
	}

	for (i = 0; i < 10; i++) {
		if (numcnt[i] == 6) {
			tri += 2;
			numcnt[i] -= 6;
		}
		else if (numcnt[i] >= 3 && numcnt[i] < 6) {
			tri++;
			numcnt[i] -= 3;
		}
	}

	for (i = 0; i < 10; i++) {
		if (numcnt[i] >= 2 && numcnt[i + 1] >= 2 && numcnt[i + 2] >= 2) {
			numcnt[i] -= 2;
			numcnt[i + 1] -= 2;
			numcnt[i + 2] -= 2;
			run += 2;
		}
		else if (numcnt[i] >= 1 && numcnt[i + 1] >= 1 && numcnt[i + 2] >= 1) {
			numcnt[i] -= 1;
			numcnt[i + 1] -= 1;
			numcnt[i + 2] -= 1;
			run += 1;
		}
	}

	if (tri + run >= 2) {
		answer = 1;
	}
	else {
		answer = 0;
	}

	return answer;
}


int main() {
	// �׽�Ʈ ���̽� 1	
	int fixed1= 559599;
	int res1 = solution(fixed1);
	printf("%d\n", res1);

	
	// �׽�Ʈ ���̽� 2	
	int fixed2 = 154161;
	int res2 = solution(fixed2);
	printf("%d\n", res2);


	// �׽�Ʈ ���̽� 3	
	int fixed3 = 202234;
	int res3 = solution(fixed3);
	printf("%d\n", res3);
	
}

