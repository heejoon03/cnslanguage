#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <malloc.h>
void print(int *result);


bool find(@@@) {
	bool comp = true;
	int i = 0;
	for (i = 0; i < idx; i++) {
		if (res[i] == d) {
			comp = false;
			break;
		}
	}

	return comp;

}

int compare(const void *a, const void *b)
{
	int num1 = *(int *)a;
	int num2 = *(int *)b;

	if (num1 < num2)
		return -1;

	if (num1 > num2)
		return 1;

	return 0;
}



int* solution(int *numbers, int size) {
	int *res = (int *)malloc(sizeof(int)*((size*(size - 1)) / 2));
	int *answer = NULL;
	int s = 0;
	int i, j = 0;
	for (i = 0; i < size - 1; i++) {
		for (j = i + 1; j < size; j++) {
			int tmp = numbers[i] + numbers[j];
			if (@@@(@@@)) {
				res[s++] = tmp;
			}
		}
	}

	answer = (int *)malloc(@@@);


	for (int i = 0; i < s; i++) {
		answer[i] = res[i];
	}
	free(res);

	qsort(answer, s, sizeof(int), compare);
	return answer;
}


int main() {

	int numbers1[] = { 2,3,1,2 };
	int numbers2[] = { 2,1,3,4,1 };
	int numbers3[] = { 1,3,5,0,2,4,7 };

	// �׽�Ʈ ���̽� 1
	int *result1 = solution(numbers1, 4);
	print(result1);

	// �׽�Ʈ ���̽� 2
	int *result2 = solution(numbers2, 5);
	print(result2);

	// �׽�Ʈ ���̽� 3
	int *result3 = solution(numbers3, 7);
	print(result3);
}

// ��� �� Ȯ�� �� �ڵ�
void print(int *result) {
	int s = _msize(result) / sizeof(int);
	int i = 0;
	for (i = 0; i < s; i++) {
		printf("%d ", result[i]);
	}
	printf("\n");

	free(result);
}