#include <stdio.h>


int solution(int numbers[], int numbers_len) {
	int answer = -1;
	// �ڵ带 �ۼ��ϼ���.

	return answer;
}


int main() {

	// �׽�Ʈ ���̽� 1	
	int numbers1[] = { 2,7,8,6,1,5,3 };
	int result1 = solution(numbers1, sizeof(numbers1)/sizeof(int));
	printf("%d\n", result1);

	// �׽�Ʈ ���̽� 2
	int numbers2[] = { 4,3,2,2,9,10 };
	int result2 = solution(numbers2, sizeof(numbers2) / sizeof(int));
	printf("%d\n", result2);

	// �׽�Ʈ ���̽� 3
	int numbers3[] = { 4,5,6,7 };
	int result3 = solution(numbers3, sizeof(numbers3) / sizeof(int));
	printf("%d\n", result3);

}