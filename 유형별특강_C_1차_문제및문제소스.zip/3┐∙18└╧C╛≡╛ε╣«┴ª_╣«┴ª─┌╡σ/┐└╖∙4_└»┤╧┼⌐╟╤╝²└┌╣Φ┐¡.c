#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//Ȯ�ο� �Լ�
void print(int *res);

bool find(int *numbers, int p, int val) {
	bool result = false;

	for (int i = 0; i < p; i++) {
		if (numbers[i] == val) {
			result = true;
			break;
		}
	}

	return result;
}


int* solution(int numbers[], int numbers_len) {
	int *res = (int *)malloc(sizeof(int) * numbers_len);
	int *answer;
	int p = 0;

	res[p++] = numbers[p];

	for (int i = 1; i < numbers_len; i++) {
		if (find(res, p, numbers[i])) {
			res[p++] = numbers[i];
		}
	}

	answer = (int *)malloc(sizeof(int)*p);

	for (int i = 0; i < p; i++) {
		answer[i] = res[i];
	}


	return answer;
}


int main() {
	// �׽�Ʈ ���̽� 1
	int numbers1[] = { 1,5,1,0,1,2,6,1,2 };
	int *res1 = solution(numbers1, sizeof(numbers1)/sizeof(int));
	print(res1);


	// �׽�Ʈ ���̽� 2
	int numbers2[] = { 3,3,3,4,4,3,3 };
	int *res2 = solution(numbers2, sizeof(numbers2) / sizeof(int));
	print(res2);


	// �׽�Ʈ ���̽� 3
	int numbers3[] = { 1,1,1,1,1,1,1,1 };
	int *res3 = solution(numbers3, sizeof(numbers3) / sizeof(int));
	print(res3);

}


//Ȯ�ο� �Լ�
void print(int *res) {
	int size = _msize(res)/sizeof(int);

	printf("[");
	for (int i = 0; i < size; i++) {
		printf("%d ", res[i]);
	}
	printf("]\n");
}