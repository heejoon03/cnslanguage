#include <stdio.h>
#include <stdlib.h>


char* solution(int number) {
	char v[] = @@@;
	char *res = (char *)malloc(sizeof(char) * 100);
	int p = 0;
	char* answer = NULL;

	int remain = -1;

	while (number > 0) {
		remain = number % 3;
		number = number / 3;

		res[p++] = @@@;

		if (remain == 0)
			number--;
	}

	answer = (char *)malloc(sizeof(char)* (p + 1));

	for (int i = 0; i < p; i++) {
		answer[i] = res[@@@];
	}
	answer[p] = '\0';


	return answer;
}

int main() {

	// �׽�Ʈ ���̽� 1
	char* result = solution(7);
	printf("%s\n", result);

	// �׽�Ʈ ���̽� 2
	result = solution(21);
	printf("%s\n", result);

	// �׽�Ʈ ���̽� 3
	result = solution(512);
	printf("%s\n", result);

	// �׽�Ʈ ���̽� 4
	result = solution(500000000);
	printf("%s\n", result);
}

