#include <stdio.h>
#include <stdlib.h>


int* solution(int gray, int indi) {
	int *res = (int *)malloc(sizeof(int) * 2);

	int total = @@@;
	int height = 3;

	while (1) {
		if (!(total % height)) {
			int weight = total / height;

			if (@@@) {
				res[0] = weight;
				res[1] = height;
				break;
			}
		}

		height++;
	}	

	return res;
}


int main() {
	// �׽�Ʈ ���̽� 1
	int gray = 12;
	int indi = 3;
	int *res = solution(gray, indi);
	printf("[%d, %d]\n", res[0], res[1]);


	// �׽�Ʈ ���̽� 2
	gray = 8;
	indi = 1;
	res = solution(gray, indi);
	printf("[%d, %d]\n", res[0], res[1]);


	// �׽�Ʈ ���̽� 3
	gray = 24;
	indi = 24;
	res = solution(gray, indi);
	printf("[%d, %d]\n", res[0], res[1]);

	// �׽�Ʈ ���̽� 4
	gray = 18;
	indi = 12;
	res = solution(gray, indi);
	printf("[%d, %d]\n", res[0], res[1]);

}