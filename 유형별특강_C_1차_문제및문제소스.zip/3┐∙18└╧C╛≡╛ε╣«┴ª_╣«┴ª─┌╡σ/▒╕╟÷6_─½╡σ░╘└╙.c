#include <stdio.h>



int solution(int n, int card[][5]) {	
	int answer = -1;

	// �ڵ带 �ۼ��ϼ���.

	return answer+1;
}


int main() {

	// �׽�Ʈ ���̽� 1
	int N1 = 3;
	int card1[][5] = { {7, 5, 5, 4, 9},{1, 1, 1, 1, 1},{2, 3, 3, 2, 10} };
	int result1 = solution(N1, card1);
	printf("%d\n", result1);

	// �׽�Ʈ ���̽� 2
	int N2 = 4;
	int card2[][5] = { {2, 2, 2, 2, 2},{2, 2, 2, 2, 2},{2, 2, 2, 2, 2},{2, 2, 2, 2, 2} };
	int result2 = solution(N2, card2);
	printf("%d\n", result2);
	
}