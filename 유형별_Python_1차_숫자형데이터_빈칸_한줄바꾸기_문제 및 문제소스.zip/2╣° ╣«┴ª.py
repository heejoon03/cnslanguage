def solution(positions):
    answer = 1000*1000*2
    for i in range(len(positions)):
        for j in range(len(positions)):
            x1, y1 = positions[i][0], positions[i][1]
            x2, y2 = positions[j][0], positions[j][1]
            distance = (x1-x2)**2 + (y1-y2)**2
            answer = min(answer, distance)
    return answer

positions = [[2,3],[1,4],[4,4]]
ret = solution(positions)

print("solution 함수의 반환 값은", ret, "입니다.")
