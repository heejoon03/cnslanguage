def solution(cookings, n):
    answer = 0
    cookings.sort(key = lambda x:x[1], reverse = True)
    for stock, price in cookings:
        count = min(n, stock)
        n -=count
        answer += price * n
    return answer

cookings = [[4, 3000], [3, 4000]]
n = 5
ret = solution(cookings, n)

print("solution 함수의 반환 값은", ret, "입니다.")
