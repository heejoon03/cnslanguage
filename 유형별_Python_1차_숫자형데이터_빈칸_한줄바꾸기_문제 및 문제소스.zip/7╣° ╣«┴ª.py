def Solution(round, children):
    answer = list()

    index = 1

    for i in range(0, round):

        a = [0] * 6
        b = [0] * 6

        for j in range(0, len(children[index])):
            b[children[index][j]] += 1
        for j in range(0, len(children[index-1])):
            a[children[index-1][j]] += 1

        if a[4] < b[4]:
            answer.append('B')
        else :
            if a[4] == b[4]:
                if a[3] < b[3]:
                    answer.append('B')
                else :
                    if a[3] == b[3]:
                        if a[2] < b[2]:
                            answer.append('B')
                        else :
                            if a[2] == b[2]:
                                if a[1] <  b[1] :
                                    answer.append('B')
                                else :
                                    if a[1] == b[1]:
                                        @@@
                                    else :
                                        @@@
                            else :
                                answer.append('A')
                    else :
                        answer.append('A')
            else :
                answer.append('A')

        index += 2

    return answer

round = 5
children = [[4], 
            [3, 3, 2, 1], 
            [2, 4, 3, 2, 1], 
            [4, 3, 3, 1], 
            [3, 2, 1, 1], 
            [2, 3, 2, 1], 
            [4, 3, 2, 1], 
            [4, 3, 2], 
            [4, 4, 2, 3, 1], 
            [4, 2, 4, 1 ,3]]

ret = Solution(round, children)
print("solution 함수의 반환 값은", ret, "입니다.")

round = 4
children = [[4, 3, 2, 1], 
            [1, 4, 3, 2], 
            [3, 3, 2, 1], 
            [4, 3, 3, 3], 
            [4, 3, 3, 3], 
            [3, 4, 3, 2], 
            [3, 2, 1, 1], 
            [3, 2, 1]]

ret = Solution(round, children)
print("solution 함수의 반환 값은", ret, "입니다.")
