def func_a(count):
    sum = 0
    num = 1
    while count != 0:
        sum += func_@@@(@@@)
        count //= 10
    return sum
        
def func_b(sum, index):
    return index % sum

def func_c(num):
    return num % 10

def solution(N):
    answer = 0
    for i in range(1, N+1) :
        check = func_@@@(@@@)
        if(func_@@@(@@@) == 0):
            answer+= 1
    return answer

N = 9
ret = solution(N)
print("solution 함수의 반환 값은", ret, "입니다.")

N = 21
ret = solution(N)
print("solution 함수의 반환 값은", ret, "입니다.")