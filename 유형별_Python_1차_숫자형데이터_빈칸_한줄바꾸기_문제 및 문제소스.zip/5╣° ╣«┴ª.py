def solution(number1, number2, summation):
    answer = None

    if number1 > number2:
        number1, number2 = number2, number1
    
    for i in range(summation // number1 + 1):
        if(summation - number1 * i ) % number2 == 0:
            answer = i + (summation - number1 * i) // number2 - 1
        continue
    return answer

number1 = 2
number2 = 4
summation = 8
ret = solution(number1, number2, summation)

print("solution 함수의 반환 값은", ret, "입니다.")
