def func_a(arr):
    answer = [0] * 11
    for number in arr:
        answer[number] += 1
    return answer

def func_b(arr, value):
    answer = []
    for idx, number in enumerate(arr):
        if value == number:
            answer.append(idx)
    return answer

def func_c(arr):
    answer = 0
    for number in arr:
        if answer < number:
            answer = number
    return answer

def solution(worries):
    counter = func_@@@(@@@)
    mode = func_@@@(@@@)
    answer = func_@@@(@@@)
    return answer

worries = [2, 3, 7, 3, 2, 2, 3]
ret = solution(worries)

print("solution 함수의 반환 값은", ret, "입니다.")
