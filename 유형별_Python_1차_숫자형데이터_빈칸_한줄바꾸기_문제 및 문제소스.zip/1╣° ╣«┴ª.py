def Solution(room1, room2, room3, students):

    answer = False

    for i in range (50):
        for j in range (50) :
            for k in range (50):
                if room1 * (i+1) + room2 * (j+1) + room3 * (k+1) == students:
                    answer = True

    return answer

room1 = 5
room2 = 9
room3 = 12
student = 113

ret = Solution(room1, room2, room3, student)
print("solution 함수의 반환 값은", ret, "입니다.")

room1 = 3
room2 = 6
room3 = 9
student = 112


ret = Solution(room1, room2, room3, student)
print("solution 함수의 반환 값은", ret, "입니다.")
