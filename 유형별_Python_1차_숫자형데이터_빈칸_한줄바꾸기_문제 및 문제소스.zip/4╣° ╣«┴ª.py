def solution(stores, k):
    for number in range(1000+1):
        previous =-k
        for idx, store in enumerate(stores):
            if store != number:
                continue
            if idx - previous <= k:
                return False
            previous = idx
    return True

stores1 = [2, 3, 5, 4, 2]
k1 = 4
ret1 = solution(stores1, k1)

print("solution 함수의 반환 값은", ret1, "입니다.")

stores2 = [1, 1, 5, 1, 6, 4]
k2 = 3
ret2 = solution(stores2, k2)

print("solution 함수의 반환 값은", ret2, "입니다.")
