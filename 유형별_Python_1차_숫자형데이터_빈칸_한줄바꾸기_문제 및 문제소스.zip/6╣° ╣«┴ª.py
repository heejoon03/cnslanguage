def func_a(a, b):
        return a > b

def func_b(arr):
    return len(arr)

def func_c(arr, count):
    t = 0
    s = list()

    for i in range(count - 1, -1, -1):
        if func_@@@(@@@):
            t = arr[i]
            s.append(1)
    return func_@@@(@@@)

def solution(sticks, stickCount):
    answer = 0
    answer = func_@@@(@@@)
    return answer

stickCount = 6
sticks = [6, 9, 7, 6, 4, 6]
ret = solution(sticks, stickCount)
print("solution 함수의 반환 값은", ret, "입니다.")