class Conference:
    def __init__(self, num, start, end):
        self.num = num
        self.start = start
        self.end = end

def solution(conference):
    answer = ""
    con = []
    for i in range(len(conference)):
        num = int(conference[i][0])
        start = int(conference[i][2]) * 10 + int(conference[i][3])
        end = int(conference[i][5]) * 10 + int(conference[i][6])
        con.append(Conference(num, start, end))
    con.sort(key = lambda x : x.end)
    result = []
    result.append(con[0])
    for i in range(1, len(conference)):
        if result[i].end <= con[i].start :
            result.append(con[i])
    for e in result:
        answer += str(e.num) + " "
    return answer


conference = ["1-01:10", "2-05:06", "3-13:15", "4-14:17", "5-08:14", "6-03:12"]
ret = solution(conference)
print("solution 함수의 반환 값은 " + ret + "입니다.")