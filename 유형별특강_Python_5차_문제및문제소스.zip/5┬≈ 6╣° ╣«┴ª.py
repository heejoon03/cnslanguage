def func_a(arr, len):
    answer = [0] * (len + 1)
    for i in range(len):
        if i == 0:
            answer[i] = arr[i] - 8 * 60
        else:
            answer[i] = arr[i] - (arr[i-1] + 60)
    answer[len] = 24 * 60 - (arr[len - 1] + 60)
    return answer

def func_b(arr, len):
    answer  = [0] * len
    for i in range(len):
        number1 = int(arr[i][0]) * 10 + int(arr[i][1])
        number2 = int(arr[i][3]) * 10 + int(arr[i][4])
        answer[i] = number1 * 60 + number2
    return answer

def func_c(arr, len):
    answer = 0
    for i in range(len):
        answer += arr[i]
    return answer

def solution(position):
    occupied = func_@@@(@@@)
    unoccupied = func_@@@(@@@)
    answer = func_@@@(@@@)
    return answer

timetable = ["11:30" , "16:00"]
ret = solution(timetable)
print("solution 함수의 반환값은", ret, "입니다.")