info = []
r = []

def search(c):
    if not c in r:
        r.append(c)
        r.append(" ")
    for i in range(len(info[c])):
        if len(info[c]) <= i:
            continue
        if int(info[c][i]) != 0:
            next = info[c][i]
            search(next)

def solution(maze):
    answer = ""
    maximum = 0
    minimum = 10000
    for e in maze:
        start = int(e[0]) * 10 + int(e[1])
        end = int(e[3]) * 10 + int(e[4])
        tempMax = max(start, end)
        tempMin = min(start, end)
        maximum = max(maximum, tempMax)
        minimum = min(minimum, tempMin)
    for i in range(maximum+1):
        info.append(list())
    for e in maze:
        start = int(e[0]) * 10 + int(e[1])
        end = int(e[3]) * 10 + int(e[4])
        info[start].append(end)
        info[end].append(start)
    for i in range(len(info)):
        info[0].sort()
    search(minimum)
    for e in r:
        answer += str(e)
    return answer

maze = ["10-13", "13-17", "17-10", "39-10", "25-13", "13-39"]
ret = solution(maze)
print("solution 함수의 반환 값은 " + ret + "입니다.")