
def solution(timetable):
    answer = [0]
    #여기를 구현해 주세요.
    return answer

timetable = ["09:00:00~12:00:00" , "12:10:00~14:10:00" , "14:20:00~15:20:00"]
ret = solution(timetable)
print("solution 함수의 반환값은", ret, "입니다.")