def solution(position):
    answer = []
    rowDir = [0, -1, 0, 1]
    colDir = [-1, 0 ,1, 0]

    for i in range(4):
        moveCol = position[0]
        moveRow = position[1]
        while True:
            moveCol = chr(@@@)
            moveRow = chr(@@@)
            if moveRow >= @@@ and moveCol >= @@@ and moveRow <= @@@ and moveCol <= @@@:
                answer.append(moveCol + "" + moveRow)
            else:
                break

    return answer

position = "d4"
ret = solution(position)
print("solution 함수의 반환값은", ret, "입니다.")