def solution(timetable, interval):
    answer = []
    intervalToInt = int(interval[0]) * 10 + int(interval[1])

    startTime = timetable[0]
    endTime = timetable[1]

    while True:
        hour = int(startTime[0]) * 10 + int(startTime[1])
        min = int(startTime[3]) * 10 + int(startTime[4])
        min += intervalToInt

        if min >= 60:
            hour += (60 - min) + 10
            min -= 60
        cHour = str(hour)
        cMin = str(min)

        if len(cHour) == 1:
            cHour = "0" + cHour
        if len(cMin) == 1:
            cMin = "0" + cMin 

        startTime = cHour + ":" + cMin

        cStartTimeHour = int(startTime[0]) * 10 + int(startTime[1])
        cStartTimeMin = int(startTime[3]) * 10 + int(startTime[4])
        endTimeHour = int(endTime[0]) * 10 + int(endTime[1])
        endTimeMin = int(endTime[3]) * 10 + int(endTime[4])

        if cStartTimeHour > endTimeHour:
            break
        elif cStartTimeHour == endTimeHour and cStartTimeMin > endTimeMin:
            break
        elif cStartTimeHour == endTimeHour and cStartTimeHour == endTimeMin:
            answer.append(startTime)
            break
        answer.append(startTime)
    return answer

timetable1 = ["12:00", "13:40"]
interval1 = "18"
ret1 = solution(timetable1, interval1)
print("solution 함수의 반환값은", ret1, "입니다.")

timetable2 = [ "15:20", "17:40"]
interval2 = "20"
ret2 = solution(timetable2, interval2)
print("solution 함수의 반환값은", ret2, "입니다.")