class Hamming:
    def __init__(self):
        self.visit = [False] * 1001
        self.adj = []
        self.flag = False
        self.n = 0
        self.k = 0
        self.a = 0
        self.b = 0
        self.ans = ""

    def func_a(self, v, s):
        if v == self.b:
            self.flag = True
            self.ans = s
        else :
            for i in range(1, self.n+1):
                if self.visit[i] == False and self.adj[v][i] == 1:
                    self.visit[i] = True
                    self.func_@@@(@@@)

    def func_b(self, x, y):
        self.n = len(x)
        self.k = len(x[0])
        self.a = y[0]
        self.b = y[1] 
        for i in range(1, len(x)):
            for j in range(i+1, len(x) + 1):
                if self.func_@@@(@@@):
                    self.adj[i][j] = 1
                    self.adj[j][i] = 1

    def func_c(self, s1, s2):
        cnt = 0
        for i in range(self.k):
            if s1[i] != s2[i]:
                cnt += 1
                if cnt >= 2:
                    return False
        if cnt == 0:
            return False
        else :
            return True

    def solution(self, hamming, question):
        answer = ""
        for i in range(len(hamming)+1):
            self.adj.append([0]*(len(hamming) + 1))
        self.func_@@@(@@@)
        self.visit[question[0]] = True
        if self.func_@@@(@@@) == False:
            answer = "-1"
        else :
            answer = self.ans
        return answer

hamming = ["000", "111", "010", "110", "001"]
question = [ 1, 2 ]
h = Hamming()
ret = h.solution(hamming, question)
print("solution 함수의 반환값은", ret, "입니다.")