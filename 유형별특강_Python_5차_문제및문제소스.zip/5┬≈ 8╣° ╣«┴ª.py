
def solution(timetable):
    answer = 0
    #여기를 구현해 주세요.  
    return answer

timetable1 = ["09:00:30", "12:20:50"]
ret1 = solution(timetable1)
print("solution 함수의 반환값은", ret1, "입니다.")

timetable2 = ["12:00:00", "13:22:00"]
ret2 = solution(timetable2)
print("solution 함수의 반환값은", ret2, "입니다.")