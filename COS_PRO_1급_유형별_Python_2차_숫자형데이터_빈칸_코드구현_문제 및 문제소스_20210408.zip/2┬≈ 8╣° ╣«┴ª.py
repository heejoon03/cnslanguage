﻿
def solution(numbers):
    answer = 0
    #이곳을 구현해 주세요.
    return answer

numbers = [4, 3, 2, 2, 9, 10]
ret = solution(numbers)
print("solution 메소드의 반환 값은", ret, "입니다.")