
def solution(n, k, desk):
    answer = 0
    #이곳을 구현해 주세요.
    return answer

n1 = 20
k1 = 1
desk1 = [2,2,1,2,1,1,2,2,1,2,2,1,1,1,2,1,2,1,2,1]
ret1 = solution(n1, k1, desk1);	
print("solution 메소드의 반환 값은", ret1, "입니다.")

n2 = 20
k2 = 2
desk2 = [2,2,2,2,2,1,1,1,1,1,2,1,2,1,2,1,2,2,2,1]
ret2 = solution(n2, k2, desk2);	
print("solution 메소드의 반환 값은", ret2, "입니다.")