import copy

def solution(n, m, students):
	answer = list();
	#이곳을 구현해 주세요.
	return answer;	

n1 = 5
m1 = 5
students1 = [[1, 2], [1, 5], [3, 4], [3, 5], [4, 5]]
ret1 = solution(n1, m1, students1)
print("solution 메소드의 반환 값은 ", ret1 , " 입니다.")

n2 = 5
m2 = 5
students2 = [[1, 2], [1, 3], [1, 5], [2, 5], [3, 4], [3, 5]]
ret2 = solution(n2, m2, students2)

print("solution 메소드의 반환 값은 ", ret2 , " 입니다.")