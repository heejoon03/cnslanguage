
class Zugling:
    def __init__(self, row, col, time):
        self.row = row
        self.col = col
        self.time = time
 

def solution(c, r, grid, startCol, startRow):
    answer = 0
    #이곳을 구현해 주세요.
    return answer
 
 
c = 7
r = 8
grid = 	[[0,0,1,0,0,0,0], 
		[0,0,1,1,0,0,0], 
		[0,0,0,1,1,0,0], 
		[1,0,1,1,1,1,1], 
		[1,1,1,1,0,1,1], 
		[0,0,1,1,1,0,0], 
		[0,0,1,1,1,0,0], 
		[0,0,0,1,0,0,0]]
startCol = 3
startRow = 5
ret = solution(c, r, grid, startCol, startRow)
print("solution 함수의 반환 값은", ret, "입니다.")