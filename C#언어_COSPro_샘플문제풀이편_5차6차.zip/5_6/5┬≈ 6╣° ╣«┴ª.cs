using System;
using System.Collections;
using System.Collections.Generic;

class Solution
    {
        public string solution(string s1, string s2, int p, int q)
        {  
            string answer = "";
	 // 여기에 코드를 작성해주세요.
            return answer;
        }

        // 아래는 테스트케이스 출력을 해보기 위한 main 메소드입니다. 아래에는 잘못된 부분이 없으니 위의 코드만 수정하세요.
        public static void Main(string[] args)
        {
            Solution sol = new Solution();
            string s1 = "112001";
            string s2 = "12010";
            int p = 3;
            int q = 8;
            string ret = sol.solution(s1, s2, p, q);

            // [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
            Console.WriteLine("solution 메소드의 반환 값은 " + ret + " 입니다.");
        }
    }