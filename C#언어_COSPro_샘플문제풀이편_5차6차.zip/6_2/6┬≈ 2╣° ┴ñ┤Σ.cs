using System;

class Solution
    {
		public int solution(int K, string[] words)
		{
			// 여기에 코드를 작성해주세요.
			int answer = 0;

			string temp = "";

			foreach(string e in words)
            {
				if((temp + e).Length >= 9)
                {
					answer++;
					temp = "";
				}

				temp += e;
			}

			return answer;
		}
		public static void Main(string[] args)
		{
			Solution sol = new Solution();
			int K = 10;
			string[] words = { "nice", "happy", "hello", "world", "hi" };
			int ret = sol.solution(K, words);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret + " 입니다.");
		}
	}