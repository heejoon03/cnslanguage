using System;

class Solution
    {
		public int solution(int[] arr, int K)
		{
			// 여기에 코드를 작성해주세요.
			int answer = 1000;
			return answer;
		}

		public static void Main(string[] args)
		{
			Solution sol = new Solution();
			int[] arr = { 9, 11, 9, 6, 4, 19 };
			int K = 4;
			int ret = sol.solution(arr, K);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret + "입니다.");
		}
	}