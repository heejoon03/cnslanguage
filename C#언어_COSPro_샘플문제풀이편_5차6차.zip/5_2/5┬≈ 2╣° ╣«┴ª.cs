using System;

    class Solution
    {
        public int solution(int[,] walls)
        {
            int answer = 0;

            //코드 입력

            return answer;
        }

        static void Main(string[] args)
        {
            Solution sol = new Solution();
            int[,] walls = { { 1, 4 }, { 2, 6 }, { 3, 5 }, { 5, 3 }, { 6, 2 } };
            int ret = sol.solution(walls);

            // [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
            Console.WriteLine("solution 메소드의 반환 값은 " + ret + " 입니다.");
        }
    }