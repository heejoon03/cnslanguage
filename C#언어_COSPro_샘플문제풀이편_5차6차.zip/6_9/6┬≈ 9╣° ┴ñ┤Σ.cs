using System;
using System.Collections;
using System.Collections.Generic;
 
class Solution
    {
        int func_a(List<int> stack)
        {
            int item = stack[stack.Count - 1];
            stack.RemoveAt(stack.Count - 1);
            return item;
        }

        void func_b(List<int> stack1, List<int> stack2)
        {
            while (!func_c(stack1))
            {
                int item = func_a(stack1);
                stack2.Add(item);
            }
        }

        bool func_c(List<int> stack)
        {
            return (stack.Count == 0);
        }

        public int solution(List<int> stack1, List<int> stack2)
        {
            if (func_c(stack2))
            {
                func_b(stack1, stack2);
            }
            int answer = (int)func_a(stack2);
            return answer;
        }

        public static void Main(string[] args)
        {
            Solution sol = new Solution();

            List<int> stack1_1 = new List<int>();
            List<int> stack2_1 = new List<int>();
            stack1_1.Add(1);
            stack1_1.Add(2);
            stack2_1.Add(3);
            stack2_1.Add(4);
            int ret1 = sol.solution(stack1_1, stack2_1);
            Console.WriteLine("solution 메소드의 반환 값은 " + ret1 + " 입니다.");


            List<int> stack1_2 = new List<int>();
            List<int> stack2_2 = new List<int>();
            stack1_2.Add(1);
            stack1_2.Add(2);
            stack1_2.Add(3);
            int ret2 = sol.solution(stack1_2, stack2_2);
            Console.WriteLine("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
        }
    }