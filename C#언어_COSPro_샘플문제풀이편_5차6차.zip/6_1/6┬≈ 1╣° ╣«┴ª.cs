using System;
using System.Collections;
using System.Collections.Generic;


	class Solution
    {
		public int solution(int n, int[,] garden)
		{
			int answer = 0;

			//여기 코드를 작성하세요.

			return answer;
		}

		public static void Main(string[] args)
		{
			Solution sol = new Solution();
			int n1 = 3;
			int[,] garden1 = { { 0, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } };
			int ret1 = sol.solution(n1, garden1);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret1 + " 입니다.");

			int n2 = 2;
			int[,] garden2 = { { 1, 1 }, { 1, 1 } };
			int ret2 = sol.solution(n2, garden2);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
		}
	}