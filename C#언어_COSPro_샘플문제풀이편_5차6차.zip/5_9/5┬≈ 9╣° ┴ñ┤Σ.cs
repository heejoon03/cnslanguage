using System;
using System.Collections;
using System.Collections.Generic;

class Solution
    {
		public int solution(int number, int target)
		{
			// 여기에 코드를 작성해주세요.
			int answer = 0;

			int[] visited = new int[10001];
			Queue<int> q = new Queue<int>();
			q.Enqueue(number);
			visited[number] = 1;

			while (q.Count != 0)
			{
				int x = q.Dequeue();

				if (x == target)
					break;

				if (x + 1 <= 10000 && visited[x + 1] == 0)
				{
					visited[x + 1] = visited[x] + 1;
					q.Enqueue(x + 1);
				}
				if (x - 1 >= 0 && visited[x - 1] == 0)
				{
					visited[x - 1] = visited[x] + 1;
					q.Enqueue(x - 1);
				}
				if (2 * x <= 10000 && visited[2 * x] == 0)
				{
					visited[2 * x] = visited[x] + 1;
					q.Enqueue(2 * x);
				}
			}

			answer = visited[target] - 1;
			return answer;
		}

		public static void Main(string[] args)
		{
			Solution sol = new Solution();
			int number1 = 5;
			int target1 = 9;
			int ret1 = sol.solution(number1, target1);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret1 + " 입니다.");

			int number2 = 3;
			int target2 = 11;
			int ret2 = sol.solution(number2, target2);

			// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
			Console.WriteLine("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
		}
	}