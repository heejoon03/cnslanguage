import java.util.*;

class Janggi{
	public int row;
	public int col;
	public int cnt;
	public Janggi(int row, int col, int cnt) {
		this.row = row;
		this.col = col;
		this.cnt = cnt;
	}
}

public class MainClass
{	
	public static int solution(String horse, String sol){
		int answer = 0;
		boolean visit[][] = new boolean[10][10];
		int solRow = sol.charAt(0) - '0';
		int solCol = sol.charAt(2) - '0';
		int rowDir[] = {-2, -1, 1, 2, 2, 1, -1, -2};
		int colDir[] = {-1, -2, -2, -1, 1, 2, 2, 1};
		
		Janggi h = new Janggi(horse.charAt(0) - '0', horse.charAt(2) - '0', 0);
		visit[horse.charAt(0) - '0'][horse.charAt(2) - '0'] = true;
		
		Queue<Janggi> q = new LinkedList<Janggi>();	
		q.add(h);
		
		while(!q.isEmpty()) {
			for(int i = 0 ; i < 8 ; i++) {
				int nextRow = q.peek().row + rowDir[i];
				int nextCol = q.peek().col + colDir[i];
				int nextMove = q.peek().cnt + 1;
				if(nextRow >= 1 && nextCol >= 1 && nextRow <= 9 && nextCol <= 9) {
					if(visit[nextRow][nextCol] == false) {
						Janggi t = new Janggi(nextRow, nextCol, nextMove);
						q.add(t);
					}
				}
			}
			
			if(@@@) {
				answer = q.peek().cnt;
				@@@;
			}
			@@@;
		}
		
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String horse = "3 5";
		String sol = "2 8";
		int ret = solution(horse, sol);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
