import java.util.*;

//필요한 코드는 여기에 추가로 구현해 주세요.

public class MainClass
{	
	public static int solution(String horse, String sol){
		int answer = 0;
		//코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String horse = "3 5";
		String sol = "2 8";
		int ret = solution(horse, sol);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
