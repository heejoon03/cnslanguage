import java.util.*;

public class MainClass
{	
	static ArrayList<String> list;
	static int N;

	public static void search(int n, int k, String t) {
		if(t.length() >= k){
			list.add(t);
		}
		else{
			for(int i = n ; i <= N ; i++){
				search(i+1, k, t + String.valueOf(i));
			}
		}
	}
	
	public static String solution(int n, int k, String str){
		String answer = "NONE";	
		list = new ArrayList<String>();
		N = n;
		search(1, k, "");
		for(int i = 0 ; i < list.size() ; i++) {
			if(list.get(i).equals(str)) {
				answer = list.get(i+1);
				break;
			}
		}
		return answer;
	}
	
	public static void main(String[] args)
	{	
		int n1 = 5;
		int k1 = 3;
		String str1 = "145";	
		String ret1 = solution(n1, k1, str1);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
		
		int n2 = 5;
		int k2 = 3;
		String str2 = "345";	
		String ret2 = solution(n2, k2, str2);
		System.out.println("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
