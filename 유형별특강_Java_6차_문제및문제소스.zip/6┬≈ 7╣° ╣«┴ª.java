import java.util.*;

//필요한 부분은 여기에 추가로 구현해 주세요.

public class MainClass
{	
	public static int solution(String n){
		int answer = 0;
		//코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String n = "300";
		int ret = solution(n);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
