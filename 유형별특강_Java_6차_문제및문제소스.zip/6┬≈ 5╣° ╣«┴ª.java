import java.util.*;

interface Hobby{
	public boolean Do(String time);
	public int Satisfy();
}

class ReadBook @@@{
	private int hrs; 
	private int min;
	private int hard;
	private int cnt;
	public ReadBook() {
		hrs = 1;
		min = 15;
		hard = 3;
	}
	@@@{
		int startHrs = (time.charAt(0) - '0') * 10 + (time.charAt(1) - '0');
		int startMin = (time.charAt(3) - '0') * 10 + (time.charAt(4) - '0');
		int endHrs = (time.charAt(6) - '0') * 10 + (time.charAt(7) - '0');
		int endMin = (time.charAt(9) - '0') * 10 + (time.charAt(10) - '0');	
		int ret = (endHrs - startHrs) * 60 + (Math.abs(endMin - startMin));
		cnt = @@@;
		return @@@;
	}
	@@@{
		int ans = 0;
		if(hard > cnt) {
			for(int i = 1 ; i <= cnt; i++) {
				ans += i;
			}
		}
		else {
			for(int i = 1 ; i <= cnt ; i++) {
				ans += @@@;
			}
		}
		return ans;
	}
}

class DrawingPicture @@@{
	private int hrs;
	private int min;
	private int hard;
	private int cnt;
	public DrawingPicture() {
		hrs = 1;
		min = 0;
		hard = 3;
	}
	@@@{
		int startHrs = (time.charAt(0) - '0') * 10 + (time.charAt(1) - '0');
		int startMin = (time.charAt(3) - '0') * 10 + (time.charAt(4) - '0');
		int endHrs = (time.charAt(6) - '0') * 10 + (time.charAt(7) - '0');
		int endMin = (time.charAt(9) - '0') * 10 + (time.charAt(10) - '0');	
		int ret = (endHrs - startHrs) * 60 + (Math.abs(endMin - startMin));
		cnt = @@@;
		return @@@;
	}
	@@@{
		int ans = 0;
		if(hard > cnt) {
			for(int i = 1 ; i <= cnt; i++) {
				ans += i;
			}
		}
		else {
			for(int i = 1 ; i <= cnt ; i++) {
				ans += @@@;
			}
		}
		return ans;
	}
}

class WatchingMovie @@@{
	private int hrs;
	private int min;
	private int hard;
	private int cnt;
	public WatchingMovie() {
		hrs = 1;
		min = 30;
		hard = 2;
	}
	@@@{
		int startHrs = (time.charAt(0) - '0') * 10 + (time.charAt(1) - '0');
		int startMin = (time.charAt(3) - '0') * 10 + (time.charAt(4) - '0');
		int endHrs = (time.charAt(6) - '0') * 10 + (time.charAt(7) - '0');
		int endMin = (time.charAt(9) - '0') * 10 + (time.charAt(10) - '0');	
		int ret = (endHrs - startHrs) * 60 + (Math.abs(endMin - startMin));
		cnt = @@@;
		return @@@;
	}
	@@@{
		int ans = 0;
		if(hard > cnt) {
			for(int i = 1 ; i <= cnt; i++) {
				ans += i;
			}
		}
		else {
			for(int i = 1 ; i <= cnt ; i++) {
				ans +=  @@@; 
			}
		}
		return ans;
	}
}

class Me{
	private ArrayList<Hobby> hobbies;
	public Me(String time) {
		hobbies = new ArrayList<Hobby>();
		hobbies.add(new ReadBook());
		hobbies.add(new DrawingPicture());
		hobbies.add(new WatchingMovie());
		for(int i = 0 ; i < hobbies.size(); i++) {
			if(!hobbies.get(i).Do(time)) {
				hobbies.remove(i);
			}
		}
	}
	
	public int check() {
		int ans = 0;
		for(int i = 0 ; i < hobbies.size(); i++) {
			ans += hobbies.get(i).Satisfy();
		}
		return ans;
	}
}


public class MainClass
{	
	public static int solution(String hobbyTime){
		int answer = 0;
		Me m = new Me(hobbyTime);
		answer = m.check();
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String hobbyTime = "10:15~16:30";
		int ret = solution(hobbyTime);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
