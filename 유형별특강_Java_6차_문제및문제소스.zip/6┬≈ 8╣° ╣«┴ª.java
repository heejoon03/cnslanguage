import java.util.*;

//추가적인 부분이 필요하다면 구현해 주세요.

public class MainClass 
{	
	public static int[] solution(char[] card)
	{
		int[] answer = new int[card.length];
		//코드를 구현해 주세요.
		return answer;
	}
	
	public static void main(String[] args) 
	{
		char[] card = { 'a', 'r', 'd', 'e', 'w' };
		int[] ret = solution(card);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret)+ " 입니다.");
	}
}







