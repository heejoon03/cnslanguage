import java.util.*;

public class MainClass
{	
	public static int solution(String s){
		int answer = 0;
		int dp[] = new int[210];
		int str[] = new int[s.length() / 2 + 1];
		int index = 0;
		for(int i = 0 ; i < s.length() ; i++) {
			if(s.charAt(i) != ' ') {
				str[index++] = Integer.valueOf(s.charAt(i) - '0');
			}
		}
		dp[0] = 1;
		for(int i = 1 ; i < str.length; i++) {
			dp[i] = 1;
			for(int j = 0 ; j < i ; j++) {
				if(str[j] < str[i] || dp[j] > dp[i]) {
					dp[i] = dp[j] + 1;
				}
			}
		}
		int result = 0;
		for(int i = 1 ; i < str.length; i++) {
			result = Math.max(result, dp[i]);
		}
		answer = str.length - result; 
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String s = "3 7 5 2 6 1 4";	
		int ret = solution(s);
		System.out.println("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
