import java.util.*;

public class MainClass
{	
	static int[][] board;
	static String[] t;
	static int w = 0;
	static int b = 0;
	static boolean check = false;
	
	public static void func_a(int r, int c, int s){
		for(int i = 0 ; i < r; i++){
			for(int j = 0 ; j < c; j++){
				if(t[i].charAt(j) == '0'){
					board[i][j] = 0;
				}
				else{
					board[i][j] = 1;
				}
			}
		}
	}
	
	public static void func_b(int r, int c, int s)
	{
		func_@@@(@@@);
		if(check) {
			if(board[r][c] == 0) {
				w++;
			}
			else {
				b++;
			}
			return;
		}
		
		int newSize = s / 2;
		func_@@@(@@@); 
		func_@@@(@@@); 
		func_@@@(@@@); 
		func_@@@(@@@); 
	}
	
	public static void func_c(int r, int c, int s)
	{
		int color = board[r][c];
		for(int i = r ; i < r + s; i++) {
			for(int j = c ; j < c + s ; j++) {
				if(board[i][j] != color) {
					check = false;
					return;
				}
			}
		}
		check = true;
	}
	
	public static int[] solution(String[] s){
		int[] answer = new int[2];
		t = s;
		board = new int[s.length][s[0].length()];
		func_@@@(@@@);
		func_@@@(@@@);
		answer[0] = w;
		answer[1] = b;
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String[] s = {"11000011",
		              "11000011",
		              "00001100",
		              "00001100",
		              "10001111",
		              "01001111",
		              "00111111",
		              "00111111"};
		int[] ret = solution(s);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}
