import java.util.*;

public class MainClass
{	
	static int[] number;
	static int[] combination;

	public static void search(int s, int d, ArrayList<String> ans) {
		if(d == 6) {
			String temp = "";
			for(int i = 0 ; i < 6 ; i++) {
				temp += combination[i] + " ";
			}
			ans.add(temp);
		}
		else {
			for(int i = s ; i < number.length; i++) {
				combination[d] = number[i];
				search(i+1, d+1, ans);
			}
		}
	}
	
	public static ArrayList<String> solution(String num){
		ArrayList<String> answer = new ArrayList<String>();		
		number = new int[num.length() / 2 + 1];
		combination = new int[num.length() / 2 + 1];
		String temp = "";
		int index = 0;
		for(int i = 0 ; i < num.length(); i++) {
			if(num.charAt(i) != ' ') {
				temp += num.charAt(i);
			}
			else {
				number[index++] = Integer.valueOf(temp);
				temp = "";
			}
		}
		search(0,0, answer);
		for(int i = 0 ; i < answer.size(); i++) {
			answer.set(i, answer.get(i).substring(0, answer.get(i).length() - 1));
		}
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String num = "1 2 3 4 5 6 7";
		ArrayList<String> ret1 = solution(num);
		System.out.println("solution 함수의 반환 값은 " + ret1 + " 입니다.");
	}
}
