import java.util.*;

interface IDamageable
{
	public int GetDamage();
	public void SetDamage(int damage);
}

class Player @@@
{
	public int damage;
	
	public Player(int damage)
	{
		this.damage = damage;
	}
	
	@@@
	{
		return damage;
	}
	
	@@@
	{
		this.damage = damage;
	}
}

class Fruit @@@
{
	public int damage;
	
	public Fruit(int damage)
	{
		this.damage = damage;
	}
	
	@@@
	{
		return damage;
	}
	
	@@@
	{
		if(damage > 0)
		{
			this.damage = damage * -1;
		}
		else
		{
			this.damage = damage;
		}
	}
}

public class Main 
{
	public static boolean[] solution(int damage, int recovery)
	{
		boolean[] answer = new boolean[2];
		
		Player player = new Player(100);
		Fruit fruit = new Fruit(-20);

		int prevPlayerDamage = player.damage;
		int prevFruitRecovery = fruit.damage;

		player.SetDamage(damage);
		fruit.SetDamage(recovery);

		answer[0] = (prevPlayerDamage < player.GetDamage());
		answer[1] = (recovery < 0);
		
		return answer;
	}
	
	public static void main(String[] args) 
	{
		int damage = 200;
		int recovery = 30;
		boolean[] ret = solution(damage, recovery);
		System.out.println("solution 메소드의 반환 값은 "+ Arrays.toString(ret) + " 입니다.");
	}
}
