import java.util.*;

class Virus
{
	public int row;
	public int col;
	public int count;
	
	public Virus(int row, int col, int count)
	{
		this.row = row;
		this.col = col;
		this.count = count;
	}
}

public class Main 
{
	public static void func_a(int[][] visit, int[][] grid, Queue<Virus> bfs, int m, int n)
	{
		for(int i = 0 ; i < n ; i++)
		{
			for(int j = 0 ; j < m ; j++)
			{
				if(grid[i][j] == 1)
				{
					bfs.add(new Virus(i,j,0));
					visit[i][j] = 1;
				}
				else if(grid[i][j] == -1)
				{
					visit[i][j] = 1;
				}
			}
		}
	}
	
	public static int func_b(Queue<Virus> bfs, int[][] visit, int[] rDir, int[] cDir, int result, int m, int n)
	{
		Virus a = bfs.peek();
		bfs.poll();
		result = Math.max(result, a.count);

		for(int i = 0 ; i < 4 ; i++)
		{
			int nextRow = a.row + rDir[i];
			int nextCol = a.col + cDir[i];
			if(nextRow >= 0 && nextCol >= 0 && nextRow < n && nextCol < m)
			{
				if(visit[nextRow][nextCol] == 0)
				{
					bfs.add(new Virus(nextRow, nextCol, a.count + 1));
					visit[nextRow][nextCol] = 1	;
				}
			}
		}

		return result;
	}
	
	public static int func_c(int[][] visit, Queue<Virus> bfs, int m, int n)
	{
		int result = 0;
		int[] rowDir = {-1, 0, +1, 0};
		int[] colDir = {0, +1, 0, -1};

		if (bfs.isEmpty())
		{
			result = -1;
		}		
		else
		{
			while(!bfs.isEmpty())
			{
				result = func_@@@(@@@);

				for(int i = 0; i < n ; i++)
				{
					for(int j = 0; j < m ; j++)
					{
						if (visit[i][j] == 0)							
						{
							result = -1;
						}
					}
				}	
			}		
		}
			
		return result;
	}

	public static int solution(int m, int n, int[][] grid)
	{
		int answer = 0;
				
		int[][] visit = new int[n][m];
		Queue<Virus> bfs = new LinkedList<Virus>();

		func_@@@(@@@);
		answer = func_@@@(@@@);

		return answer;
	}
	
	public static void main(String[] args) 
	{
		int m = 6;
		int n = 4;
		int[][] grid = {{0, 0, 0, 0, 0, 0,}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1}};
		int ret = solution(m, n, grid);
		System.out.println("solution 메소드의 반환 값은 "+ ret + " 입니다.");
	}
}
