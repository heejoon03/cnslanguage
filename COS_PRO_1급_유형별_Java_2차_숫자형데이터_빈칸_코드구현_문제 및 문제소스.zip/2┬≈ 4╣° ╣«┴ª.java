import java.util.*;

public class Main 
{
	public static int[] solution(int n, int m, int[][] students)
	{
		int[] answer;
		//여기를 구현해 주세요.
		
		return answer;
	}
	
	public static void main(String[] args) 
	{
		int n1 = 5;
		int m1 = 5;
		int[][] students1 = {{1, 2}, {1, 5}, {3, 4}, {3, 5}, {4, 5}};
		int[] ret1 = solution(n1, m1, students1);
		System.out.println("solution 메소드의 반환 값은 " + Arrays.toString(ret1) + " 입니다.");

		int n2 = 5;
		int m2 = 5;
		int[][] students2 = {{1, 2}, {1, 3}, {1, 5}, {2, 5}, {3, 4}, {3, 5}};
		int[] ret2 = solution(n2, m2, students2);
		System.out.println("solution 메소드의 반환 값은 " + Arrays.toString(ret2) + " 입니다.");
	}
}
