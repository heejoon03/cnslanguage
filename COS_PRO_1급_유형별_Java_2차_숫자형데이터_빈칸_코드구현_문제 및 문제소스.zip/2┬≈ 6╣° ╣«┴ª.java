﻿import java.util.*;

public class Main 
{
	public static double[] solution(int k, double[] scores){
		double[] answer = new double[2] ;

		// 이곳을 구현해 주세요.
		
		return answer;
	}

	public static void main(String[] args){
		int k = 2;
		double[] scores = { 9.3, 9.5, 9.6, 9.8, 9.1, 5.0, 9.3 };
		double[] ret = solution(k, scores);
		System.out.println("solution 메소드의 반환 값은 " + Arrays.toString(ret) + " 입니다.");
	}
}
