import java.util.*;

public class Main 
{
	public static void func_a(int[][] p, int[][] r)
	{
		Arrays.sort(p, new Comparator<int[]>()
		{
			public int compare(int[] pamphlets1, int[] pamphlets2)
			{
				return Integer.compare(pamphlets1[0], pamphlets2[0]);
			}
		});

		for(int i = 1 ; i <= p.length; i++)
		{
			r[i] = p[i-1].clone();
		}
	}
	
	public static int func_b(int[][] r, int[] d, int[] l)
	{
		for(int i = 1; i < r.length; i++)
		{
			d[i] = Math.max(d[i-1], d[l[i]] + r[i][1]);
		}
		
		return d[r.length - 1];
	}
	
	public static void func_c(int[][] r, int[] l, int s)
	{
		for(int i = 1 ; i < r.length ; i++)
		{
			l[i] = l[i-1];

			while(l[i] < i)
			{
				if(r[i][0] - r[l[i]][0] < s)
				{
					break;
				}
				else
				{
					l[i]++;
				}
			}
			l[i]--;
		}
	}
	
	public static int solution(int n, int s, int[][] pamphlets){
		int answer = 0;
		
		int[] limits = new int[pamphlets.length + 1];
		int[] dp = new int[pamphlets.length + 1];
		int[][] resizePamphlet = new int[pamphlets.length+1][2];
		
		func_@@@(@@@);
		func_@@@(@@@);		
		answer = func_@@@(@@@);
		return answer;
	}

	public static void main(String[] args){
		int n1 = 6;
		int s1 = 4;
		int[][] pamphlets1 = {{15, 80}, {8, 230}, {10, 100}, {17, 200}, {20, 75} ,{26, 80}};
		int ret1 = solution(n1, s1, pamphlets1);	
		System.out.println("solution 메소드의 반환 값은 " + ret1 + " 입니다.");
		
		int n2 = 9;
		int s2 = 3;
		int[][] pamphlets2 = {{8, 30}, {5, 10}, {14, 50}, {12, 80}, {8, 20}, {16, 50}, {11, 60}, {15, 40}, {10, 50}};
		int ret2 = solution(n2, s2, pamphlets2);	
		System.out.println("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
	}
}
