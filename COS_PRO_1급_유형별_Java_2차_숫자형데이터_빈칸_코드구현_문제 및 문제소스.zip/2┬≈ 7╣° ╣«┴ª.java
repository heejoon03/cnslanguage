import java.util.*;

class Zugling
{
	public int row;
	public int col;
	public int time;
	public Zugling(int row, int col, int time)
	{
		this.row = row;
		this.col = col;
		this.time = time;
	}
}

public class Main 
{	
	public static int solution(int c, int r, int[][] grid, int startCol, int startRow){
		int answer = 0;
		
		//여기에 구현해 주세요.
		
		return answer;
	}

	public static void main(String[] args){
		int c = 7;
		int r = 8;
		int[][] grid = 
			{{0,0,1,0,0,0,0}, 
			 {0,0,1,1,0,0,0}, 
			 {0,0,0,1,1,0,0}, 
			 {1,0,1,1,1,1,1}, 
			 {1,1,1,1,0,1,1}, 
			 {0,0,1,1,1,0,0}, 
			 {0,0,1,1,1,0,0}, 
			 {0,0,0,1,0,0,0}};
		int startCol = 3;
		int startRow = 5;
		
		int ret = solution(c, r, grid, startCol, startRow);	
		System.out.println("solution 메소드의 반환 값은 " + ret + " 입니다.");
	}
}
