﻿import java.util.*;

public class Main 
{
	public static int solution(int[] numbers){
		int answer = 0;
		
		//이곳을 구현해 주세요.

		return answer;
	}

	public static void main(String[] args){
		int[] numbers = { 4, 3, 2, 2, 9, 10 };
		int ret = solution(numbers);
		System.out.println("solution 메소드의 반환 값은 " + ret + " 입니다.");
	}
}
