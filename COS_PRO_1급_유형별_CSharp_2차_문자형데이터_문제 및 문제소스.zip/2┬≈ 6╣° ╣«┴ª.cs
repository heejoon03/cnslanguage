using System;
using System.Collections.Generic;

class MainClass
{
	public static int func_a(int[] arr){
		int answer = -1;
		for(int i = 0; i < arr.Length; i++)
        {
			if(answer == -1)
				answer = i;
			else if(arr[answer] < arr[i])
				answer = i;
        }
		return answer;
    }

	public static int[] func_b(string[] arr1, string[] arr2){
		int[] answer = new int[arr1.Length];
		for(int i = 0; i < arr1.Length; i++)
			for(int j = 0; j < arr2.Length; j++)
				if (arr1[i] == arr2[j])
					answer[i] += 1;
		return answer;
	}

	public static int func_c(int[] arr, int number){
		int answer = -1;
		for(int i = 0; i < arr.Length; i++)
        {
			if (arr[i] == number)
				continue;
			if (answer == -1)
				answer = i;
			else if (arr[answer] < arr[i])
				answer = i;
        }
		return answer;
	}
	
	public static string[] solution(string[] candidates, string[] names){
		int[] counter = func_@@@(@@@);
		int first = func_@@@(@@@);
		int second = func_@@@(@@@);
		string[] answer = { candidates[first], candidates[second] };
		return answer;
	}

	public static void Main(string[] args){
		string[] candidates = {"Ann", "Bob", "David"};
		string[] names = { "Bob", "Alice", "Bob", "Ann" };
		string[] ret = solution(candidates, names);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",",ret)  + "] 입니다.");
	}
}
