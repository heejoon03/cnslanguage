using System;
using System.Collections.Generic;

class MainClass
{
	public static int solution(string str)
	{
		int answer = 0;

		Stack<char> s = new Stack<char>();
        int temp = 1;

		for(int i = 0; i < str.Length; i++)
        {
            if (str[i] == '(')
            {
                temp *= 2;
                s.Push('(');
            }
            else if (str[i] == '[')
            {
                temp *= 3;
                s.Push('[');
            }
            else if (str[i] == ')' && s.Count == 0 || str[i] == ']' && s.Count == 0)
            {
                answer = -1;
                break;
            }
            else if (str[i] == ')')
            {
                if (str[i - 1] == '(')
                    answer += temp;
                s.Pop();
                temp /= 2;
            }
            else if (str[i] == ']')
            {
                if (str[i - 1] == '[')
                    answer += temp;
                s.Pop();
                temp /= 3;
            }
        }

        return answer;
	}

	public static void Main(string[] args)
	{
		string str1 = "(()[[]])([])";
		int ret1 = solution(str1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string str2 = "[(]]";
		int ret2 = solution(str2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
