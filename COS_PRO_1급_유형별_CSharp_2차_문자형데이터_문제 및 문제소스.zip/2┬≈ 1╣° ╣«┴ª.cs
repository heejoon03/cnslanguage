using System;

class MainClass
{
	public static int solution(string str, string find)
	{
		int answer = 0;

		for(int i = 0; i < str.Length ; i++)
        {
			int cnt = 0;
			int index = i;
			for(int j = 0; j < find.Length; j++)
            {
				if(str[index++] == find[j])
                {
					cnt++;
                }
            }
			if(cnt == find.Length)
            {
				answer++;
            }
        }

		return answer;
	}

	public static void Main(string[] args)
	{
		string str1 = "HOIOIOIOI";
		string find1 = "IOI";
		int ret1 = solution(str1, find1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string str2 = "MYLEVELEVELEVELEVEL";
		string find2 = "LEVEL";
		int ret2 = solution(str2, find2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}