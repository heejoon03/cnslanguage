import java.util.*;

class Pair
{
	public int x;
	public int y;

	public Pair(int x, int y)
    {
		this.x = x;
		this.y = y;
    }

	public boolean isContain(ArrayList<Pair> l)
    {
        for(Pair e : l)
        {
            if (e.x == x && e.y == y)
            {
                return true;
            }
            else if (e.x == y && e.y == x)
            {
				return true;
            }
        }

        return false;
    }
}

public class Main 
{	
	public static String solution(String[] coefficient)
	{
		String answer = "";

		int f = Integer.parseInt(coefficient[0]);
		int s = Integer.parseInt(coefficient[1]);
		int t = Integer.parseInt(coefficient[2]);

		ArrayList<Pair> fPair = new ArrayList<Pair>();
		ArrayList<Pair> tPair = new ArrayList<Pair>();
		ArrayList<Character> r = new ArrayList<Character>();
		int[] ft = { f, t };

		for(int i = 0; i < ft.length; i++)
        {
			for (int j = Math.abs(ft[i]) * -1; j <= Math.abs(ft[i]); j++)
			{
				for (int k = ft[i] * -1; k <= j ; k++)
				{
					if (j * k == ft[i] && i == 0)
					{
						Pair temp = new Pair(j, k);
						if(!temp.isContain(fPair))
                        {
							fPair.add(temp);
						}
					}
					else if(j * k == ft[i] && i == 1)
                    {
						Pair temp = new Pair(j, k);
						if(!temp.isContain(tPair))
                        {
							tPair.add(temp);
						}
					}
				}
			}
		}

		for(Pair e1 : fPair)
        {
			for(Pair e2 : tPair)
            {
				if(e1.x * e2.y + e1.y * e2.x == s)
                {
					String temp = "(" + e1.x + " " + e2.x + ")" + "(" + e1.y + " " + e2.y + "),";
					for(int i = 0 ; i < temp.length(); i++)
                    {
						r.add(temp.charAt(i));
                    }
                }
            }
        }

		for(int i = 0; i < r.size(); i++)
        {
			if(r.get(i) == ' ')
            {
				continue;
            }
			else if (r.get(i) == '1')
			{
				r.set(i, 'x');
				answer += r.get(i);
			}
			else if(r.get(i) > '1' && r.get(i) <= '9')
            {
				if(r.get(i-1) == '-')
                {
					answer += r.get(i);
				}
				else
                {
					answer += '+';
					answer += r.get(i);
				}
			}
			else
            {
				answer += r.get(i);
			}
		}

		if(answer.length() > 0)
        {
			answer = answer.substring(0, answer.length() - 1);
		}
		else
        {
			answer = "Nope";
        }
		return answer;
	}

	public static void main(String[] args)
	{
		String[] coefficient1 = {"+1","-1","-6"};
		String ret1 = solution(coefficient1);
		System.out.println("solution 메소드의 반환 값은 " + ret1 + " 입니다.");

		String[] coefficient2 = { "+2", "+1", "+6" };
		String ret2 = solution(coefficient2);
		System.out.println("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
	}
}
