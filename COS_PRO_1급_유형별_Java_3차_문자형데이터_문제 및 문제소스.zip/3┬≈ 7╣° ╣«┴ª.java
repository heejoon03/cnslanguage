import java.util.*;

public class Main 
{	
	public static int func_a(int[] arr){
		int answer = -1;
		for(int i = 0; i < arr.length; i++)
        {
			if(answer == -1)
				answer = i;
			else if(arr[answer] < arr[i])
				answer = i;
        }
		return answer;
    }

	public static int[] func_b(String[] arr1, String[] arr2){
		int[] answer = new int[arr1.length];
		for(int i = 0; i < arr1.length; i++)
			for(int j = 0; j < arr2.length; j++)
				if (arr1[i] == arr2[j])
					answer[i] += 1;
		return answer;
	}

	public static int func_c(int[] arr, int number){
		int answer = -1;
		for(int i = 0; i < arr.length; i++)
        {
			if (arr[i] == number)
				continue;
			if (answer == -1)
				answer = i;
			else if (arr[answer] < arr[i])
				answer = i;
        }
		return answer;
	}
	
	public static String[] solution(String[] popular, String[] names){
		int[] counter = func_@@@(@@@);
		int first = func_@@@(@@@);
		int second = func_@@@(@@@);
		String[] answer = { popular[first], popular[second] };
		return answer;
	}
	
	public static void main(String[] args)
	{	
		String[] popular = {"Anna", "Elsa", "Olaf"};
		String[] names = { "Anna", "Elsa", "Olaf","Hans", "Anna", "Elsa", "Elsa", "Bobuncle"};
		String[] ret = solution(popular, names);
		System.out.println("solution 함수의 반환 값은 " + Arrays.toString(ret)  + " 입니다.");
	}
}