import java.util.*;

public class Main 
{	
	public static int[] func_a(int[] arr){
		int[] answer = new int[arr.length];
		for(int i = 0; i < arr.length; i++)
			answer[i] = arr[i] / 5;
		return answer;
    }

	public static int func_b(int[] arr){
		int answer = 0;
		for (int i = 0; i < arr.length; i++)
			answer += arr[i];
		return answer;
	}

	public static int[] func_c(String[] arr){
		int[] answer = new int[arr.length];
		int number1 = 0;
		int number2 = 0;
		int begin = 0;
		int end = 0;
		for(int i = 0; i < arr.length; i++)
        {
			number1 = 10 * (arr[i].charAt(0) - '0') + (arr[i].charAt(1) - '0');
			number2 = 10 * (arr[i].charAt(3) - '0') + (arr[i].charAt(4) - '0');
			begin = 60 * number1 + number2;
			number1 = 10 * (arr[i].charAt(6) - '0') + (arr[i].charAt(7) - '0');
			number2 = 10 * (arr[i].charAt(9) - '0') + (arr[i].charAt(10) - '0');
			end = 60 * number1 + number2;
			answer[i] = end - begin;
		}
		return answer;
	}
	
	public static int solution(String[] timetable){
		int answer = 0;
		int[] time = func_@@@(@@@);
		int[] count = func_@@@(@@@);
		answer = func_@@@(@@@);
		return answer;
	}

	public static void main(String[] args){
		String[] timetable = {"10:06~10:40", "11:34~12:00"};
		int ret = solution(timetable);
		System.out.println("solution 메소드의 반환 값은 " + ret + " 입니다.");
	}
}
