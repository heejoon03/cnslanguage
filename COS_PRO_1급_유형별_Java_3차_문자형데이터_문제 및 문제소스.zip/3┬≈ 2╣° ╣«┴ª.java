import java.util.*;

public class Main 
{	
	public static int solution(String str)
	{
		int answer = 0;

		Stack<Character> s = new Stack<Character>();
        int temp = 1;

		for(int i = 0; i < str.length(); i++)
        {
            if (str.charAt(i) == '(')
            {
                temp *= 2;
                s.add('(');
            }
            else if (str.charAt(i) == '[')
            {
                temp *= 3;
                s.add('[');
            }
            else if (str.charAt(i) == ')' || str.charAt(i) == ']')
            {
                answer = -1;
                break;
            }
            else if (str.charAt(i)== ')')
            {
                if (str.charAt(i-1) == '(')
                    answer += temp;
                s.pop();
                temp /= 2;
            }
            else if (str.charAt(i) == ']')
            {
                if (str.charAt(i-1) == '[')
                    answer += temp;
                s.pop();
                temp /= 3;
            }
        }

        return answer;
	}

	public static void main(String[] args)
	{
		String str1 = "(()[[]])([])";
		int ret1 = solution(str1);
		System.out.println("solution 메소드의 반환 값은 " + ret1 + " 입니다.");

		String str2 = "[(]]";
		int ret2 = solution(str2);
		System.out.println("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
	}
}
