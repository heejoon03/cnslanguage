import java.util.*;

public class Main 
{	
	public static String solution(String text, int n){
		String[] prefix = new String[text.length()];
		for(int i = 0 ; i < text.length(); i++)
			prefix[i] = text.substring(0, i+1);
		
		String answer = "";
		ArrayList<String> result = new ArrayList<String>();
		for(int i = 0 ; i < text.length(); i++) {
			ArrayList<String> postfix = new ArrayList<String>();
			for(int j = 0 ; j < prefix[i].length(); j++) {
				postfix.add(postfix.get(j).substring(j));
			}
			for(String p : postfix) {
				result.add(p);
			}
		}
		Collections.sort(result);
		answer = result.get(n-1);	
        return answer;
	}

	public static void main(String[] args){
		String text1 = "cat";
		int n1 = 4;
		String ret1 = solution(text1, n1);
		System.out.println("solution 메소드의 반환 값은 " + ret1 + " 입니다.");
		
		String text2 = "LGCNS";
		int n2 = 9;
		String ret2 = solution(text2, n2);
		System.out.println("solution 메소드의 반환 값은 " + ret2 + " 입니다.");
	}
}