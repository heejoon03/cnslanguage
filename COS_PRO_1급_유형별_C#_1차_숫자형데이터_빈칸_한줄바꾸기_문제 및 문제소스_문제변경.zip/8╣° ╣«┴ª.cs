﻿using System;
using System.Collections.Generic;

class MainClass
{
	public static int solution(int[] numbers)
	{
		int answer = 0;

		//이곳을 구현해 주세요.

		return answer;
	}

	public static void Main(string[] args)
	{
		int[] numbers = { 4, 3, 2, 2, 9, 10 };
		int ret = solution(numbers);
		Console.WriteLine("solution 메소드의 반환 값은 " + ret + " 입니다.");
	}
}
