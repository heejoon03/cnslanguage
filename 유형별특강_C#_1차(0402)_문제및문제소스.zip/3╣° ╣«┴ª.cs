﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	public static int solution(int[][] cookings, int n)
	{
		int answer = 0;
		var order = cookings.OrderByDescending(y => y[1]);

        foreach (int[] e in cookings)
        {
            int stock = e[0];
            int price = e[1];
            int count = Math.Min(n, stock);
            n -= count;

            answer += price * n;
        }

        return answer;	
	}
	
	public static void Main(string[] args)
	{
		int[][] cookings = new int[2][];
		cookings[0] = new int[] { 4, 3000 };
		cookings[1] = new int[] { 3, 4000 };
		int n = 5;
		int ret = solution(cookings, n);
		Console.WriteLine("solution 메소드의 반환 값은 " + ret + " 입니다.");
	}
}
