﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	public static int[] func_a(int[] arr)
	{
		int[] answer = new int[11];

		foreach (int number in arr)
		{
			answer[number]++;
		}

		return answer;
	}

	public static List<int> func_b(int[] arr, int value)
	{
		List<int> answer = new List<int>();

		int idx = 0;
		foreach (int number in arr)
		{
			if (value == number)
			{
				answer.Add(idx);
			}
			idx++;
		}

		return answer;
	}

	public static int func_c(int[] arr)
	{
		int answer = 0;

		foreach (int number in arr)
		{
			if (answer < number)
			{
				answer = number;
			}
		}

		return answer;
	}

	public static List<int> solution(int[] worries)
	{
		List<int> answer = new List<int>();

		int[] counter = func_@@@(@@@);
		int mode = func_@@@(@@@);
		answer = func_@@@(@@@);

		return answer;
	}

	public static void Main(string[] args)
	{
		int[] worries = { 2, 3, 7, 3, 2, 2, 3 };
		List<int> ret = solution(worries);
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ",ret) + "]" + " 입니다.");
	}
}
