﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	public static List<char> solution(int round, int[][] children)
	{
		List<char> answer = new List<char>();

		int index = 1;

		for (int i = 0; i < round; i++)
		{
			int[] a = new int[6];
			int[] b = new int[6];

			for (int j = 0; j < children[index].Length; j++)
			{
				b[children[index][j]] += 1;
			}

			for (int j = 0; j < children[index - 1].Length; j++)
			{
				a[children[index - 1][j]] += 1;
			}

			if (a[4] < b[4])
			{
				answer.Add('B');
			}
			else
			{
				if (a[4] == b[4])
				{
					if (a[3] < b[3])
					{
						answer.Add('B');
					}
					else
					{
						if (a[3] == b[3])
						{
							if (a[2] < b[2])
							{
								answer.Add('B');
							}
							else
							{
								if (a[2] == b[2])
								{
									if (a[1] < b[1])
									{
										answer.Add('B');
									}
									else
									{
										if (a[1] == b[1])
										{
											@@@
										}
										else
										{
											@@@
										}
									}
								}
								else
								{
									answer.Add('A');
								}
							}
						}
						else
						{
							answer.Add('A');
						}
					}
				}
				else
				{
					answer.Add('A');
				}
			}

			index += 2;
		}

		return answer;
	}

	public static void Main(string[] args)
	{
		int round1 = 5;
		int[][] children1 = new int[10][];
		children1[0] = new int[] { 4 };
		children1[1] = new int[] { 3, 3, 2, 1 };
		children1[2] = new int[] { 2, 4, 3, 2, 1 };
		children1[3] = new int[] { 4, 3, 3, 1 };
		children1[4] = new int[] { 3, 2, 1, 1 };
		children1[5] = new int[] { 2, 3, 2, 1 };
		children1[6] = new int[] { 4, 3, 2, 1 };
		children1[7] = new int[] { 4, 3, 2 };
		children1[8] = new int[] { 4, 4, 2, 3, 1 };
		children1[9] = new int[] { 4, 2, 4, 1, 3 };

		List<char> ret1 = solution(round1, children1);
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ", ret1) + "]" + " 입니다.");

		int round2 = 4;
		int[][] children2 = new int[8][];
		children2[0] = new int[] { 4, 3, 2, 1 };
		children2[1] = new int[] { 1, 4, 3, 2 };
		children2[2] = new int[] { 3, 3, 2, 1 };
		children2[3] = new int[] { 4, 3, 3, 3 };
		children2[4] = new int[] { 4, 3, 3, 3 };
		children2[5] = new int[] { 3, 4, 3, 2 };
		children2[6] = new int[] { 3, 2, 1, 1 };
		children2[7] = new int[] { 3, 2, 1 };

		List<char> ret2 = solution(round2, children2);
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ", ret2) + "]" + " 입니다.");
	}
}
