﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	public static void func_a(List<List<int>> aList, List<List<int>> bList, int s, int c, int[,] p)
	{
		for (int i = 0; i < s + 1; i++)
		{
			aList.Add(new List<int>());
			bList.Add(new List<int>());
		}

		for (int i = 0; i < c; i++)
		{
			int a = p[i,0]; // better
			int b = p[i,1]; // worse

			bList[a].Add(b);
			aList[b].Add(a);
		}
	}

	public static int func_b(Queue<int> q, List<List<int>> arrList, bool[] visit)
	{
		int rank = 0;

		while (q.Count != 0)
		{
			int here = q.Dequeue();

			for (int i = 0; i < arrList[here].Count; i++)
			{
				int there = arrList[here][i];

				if (!visit[there])
				{
					rank++;
					q.Enqueue(there);
					visit[there] = true;
				}
			}
		}

		return rank;
	}

	public static int func_c(List<List<int>> arrList, int count, int find)
	{
		Queue<int> q = new Queue<int>();
		bool[] visit = new bool[count + 1];
		int result = 0;

		q.Enqueue(find);
		visit[find] = true;

		result = func_@@@(@@@);
		return result;
	}


	public static List<int> solution(int n, int m, int x, int[,] pair)
	{
		List<int> answer = new List<int>();

		List<List<int>> better = new List<List<int>>();
		List<List<int>> worse = new List<List<int>>();

		func_a(better, worse, n, m, pair);

		int best = func_@@@(@@@) + 1;
		int worst = n - func_@@@(@@@);

		answer.Add(best);
		answer.Add(worst);

		return answer;
	}

	// 아래는 테스트케이스 출력을 해보기 위한 main 메소드입니다. main 메소드는 잘못된 부분이 없으니, solution 메소드만 수정하세요.
	public static void Main(string[] args)
	{
		int n1 = 5;
		int m1 = 4;
		int x1 = 1;
		int[,] pair1 = { { 1, 2 }, { 2, 3 }, { 3, 4 }, { 4, 5 } };
		List<int> ret1 = solution(n1, m1, x1, pair1);

		// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ", ret1) + "]" + " 입니다.");

		int n2 = 5;
		int m2 = 3;
		int x2 = 1;
		int[,] pair2 = { { 2, 3 }, { 3, 4 }, { 4, 5 } };
		List<int> ret2 = solution(n2, m2, x2, pair2);

		// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ", ret2) + "]" + " 입니다.");

		int n3 = 5;
		int m3 = 5;
		int x3 = 1;
		int[,] pair3 = { { 1, 3 }, { 2, 3 }, { 3, 4 }, { 3, 5 }, { 4, 5 } };
		List<int> ret3 = solution(n3, m3, x3, pair3);
		// [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
		Console.WriteLine("solution 메소드의 반환 값은 " + "[" + string.Join(", ", ret3) + "]" + " 입니다.");
	}
}
