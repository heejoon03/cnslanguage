class Solution:
    def __init__(self, num):
        length = len(num) // 2
        self.number = [0] * (length + 1)
        self.combination = [0] * (length + 1)

    def search(self, s, d, ans):
        if d == 6:
            temp = ""
            for i in range(6):
                temp += (str(self.combination[i]) + " ")
            ans.append(temp)
        else:
            for i in range(s, len(self.number)):
                self.combination[d] = self.number[i]
                self.search(i, d+1, ans)
    
    def solution(self, num):
        answer = []
        temp = ""
        index = 0
        for i in range(len(num)):
            if num[i] != ' ':
                temp += num[i]
            else:
                self.number[index] = int(temp)
                temp = ""
                index += 1
        self.number[index] = int(temp)
        self.search(0,0,answer)
        for i in range(len(answer)):
            substring = answer[i][0:len(answer[i])-1]
            answer[i] = substring
        return answer

num = "1 2 3 4 5 6 7"
sol = Solution(num)
ret = sol.solution(num)
print("solution 함수의 반환값은", ret, "입니다.")
