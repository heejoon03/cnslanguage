def solution(s):
    answer = 0
    dp = [0] * 210
    str = [0] * (len(s) //2 + 1)
    index = 0
    for i in range(len(s)):
        if s[i] != ' ':
            str[index] = int(s[i])
            index += 1
    dp[0] = 1
    for i in range(1, len(str)):
        dp[i] = 1
        for j in range(i):
            if @@@:
                @@@
    result = 0
    for i in range(1, len(str)):
        result = max(result, dp[i])
    answer = len(str) - result
    return answer

s = "3 7 5 2 6 1 4"
ret = solution(s)
print("solution 함수의 반환값은", ret, "입니다.")