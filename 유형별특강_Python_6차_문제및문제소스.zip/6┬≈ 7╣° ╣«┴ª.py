#필요한 부분은 여기에 추가로 구현해 주세요.

def solution(n):
    answer = 0
    #코드를 구현해 주세요.
    return answer

n = "300"
ret = solution(n)
print("solution 함수의 반환값은", ret, "입니다.")