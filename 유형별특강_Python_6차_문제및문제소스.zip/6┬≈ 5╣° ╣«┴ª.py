from abc import *

class Hobby(metaclass = ABCMeta):
	@abstractmethod
	def Do(self, time):
		pass
	@abstractmethod
	def Satisfy(self):
		pass

class ReadBook(@@@):
	def __init__(self):
		self.__hrs = 1
		self.__min = 15
		self.__hard = 3
		self.__cnt = 0
	@@@:
		startHrs = int(time[0]) * 10 + int(time[1])
		startMin = int(time[3]) * 10 + int(time[4])
		endHrs = int(time[6]) * 10 + int(time[7])
		endMin = int(time[9]) * 10 + int(time[10])
		ret = (endHrs - startHrs) * 60 + (abs(endMin - startMin))
		self.__cnt = @@@
		return @@@
	@@@:
		ans = 0
		if self.__hard > self.__cnt:
			for i in range(1, self.__cnt+1):
				ans += i
		else:
			for i in range(1, self.__cnt+1):
				ans += @@@
		return ans

class DrawingPicture(@@@):
	def __init__(self):
		self.__hrs = 1
		self.__min = 0
		self.__hard = 3
		self.__cnt = 0
	@@@:
		startHrs = int(time[0]) * 10 + int(time[1])
		startMin = int(time[3]) * 10 + int(time[4])
		endHrs = int(time[6]) * 10 + int(time[7])
		endMin = int(time[9]) * 10 + int(time[10])
		ret = (endHrs - startHrs) * 60 + (abs(endMin - startMin))
		self.__cnt = @@@
		return @@@
	@@@:
		ans = 0
		if self.__hard > self.__cnt:
			for i in range(1, self.__cnt+1):
				ans += i
		else:
			for i in range(1, self.__cnt+1):
				ans += @@@
		return ans

class WatchingMovie(@@@):
	def __init__(self):
		self.__hrs = 1
		self.__min = 30
		self.__hard = 2
		self.__cnt = 0
	@@@:
		startHrs = int(time[0]) * 10 + int(time[1])
		startMin = int(time[3]) * 10 + int(time[4])
		endHrs = int(time[6]) * 10 + int(time[7])
		endMin = int(time[9]) * 10 + int(time[10])
		ret = (endHrs - startHrs) * 60 + (abs(endMin - startMin))
		self.__cnt = @@@
		return @@@
	@@@:
		ans = 0
		if self.__hard > self.__cnt:
			for i in range(1, self.__cnt+1):
				ans += i
		else:
			for i in range(1, self.__cnt+1):
				ans += @@@
		return ans


class Me:
	def __init__(self, time):
		self.__hobbies = []
		self.__hobbies.append(ReadBook())
		self.__hobbies.append(DrawingPicture())
		self.__hobbies.append(WatchingMovie())
		for i in range(len(self.__hobbies)):
			if self.__hobbies[i].Do(time) == False:
				self.__hobbies.pop(i)
	def check(self):
		ans = 0
		for i in range(len(self.__hobbies)):
			ans += self.__hobbies[i].Satisfy()
		return ans

def solution(hobbyTime):
	answer = 0
	m = Me(hobbyTime)
	answer = m.check()
	return answer

hobbyTime = "10:15~16:30"
ret = solution(hobbyTime)
print("solution 함수의 반환값은", ret, "입니다.")