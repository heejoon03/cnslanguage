#추가로 필요한 부분은 이곳에 구현해 주세요.

def solution(card):
    answer = []
    #코드를 구현해 주세요.
    return answer

card = ['a', 'r', 'd', 'e', 'w']
ret = solution(card)
print("solution 함수의 반환값은", ret, "입니다.")