class Solution:
    def __init__(self, n):
        self.list = []
        self.N = n

    def search(self, n, k, t):
        if len(t) >= k:
            self.list.append(t)
        else:
            for i in range(n, self.N+1):
                self.search(i+1, k, t + str(i))
    
    def solution(self, n, k , str):
        answer = "NONE"
        self.search(1, k, "")
        for i in range(len(self.list)):
            if self.list[i] == str:
                answer = self.list[i+1]
                break
        return answer

n1 = 5
k1 = 3
str1 = "145"
sol1 = Solution(n1)
ret1 = sol1.solution(n1,k1,str1)
print("solution 함수의 반환값은", ret1, "입니다.")

n2 = 5
k2 = 3
str2 = "345"
sol2 = Solution(n2)
ret2 = sol2.solution(n2,k2,str2)
print("solution 함수의 반환값은", ret2, "입니다.")
