class Solution:
	def __init__(self):
		self.board = []
		self.t = []
		self.w = 0
		self.b = 0
		self.check = False

	def func_a(self, r, c, s):
		for i in range(r):
			for j in range(c):
				if self.t[i][j] == '0':
					self.board[i][j] = 0
				else:
					self.board[i][j] = 1
	def func_b(self, r, c, s):
		self.func_@@@(@@@)
		if(self.check == True):
			if self.board[r][c] == 0:
				self.w += 1
			else:
				self.b += 1
			return
		newSize = s // 2
		self.func_@@@(@@@)
		self.func_@@@(@@@)
		self.func_@@@(@@@)
		self.func_@@@(@@@)
	def func_c(self, r, c, s):
		color = self.board[r][c]
		for i in range(r, r+s):
			for j in range(c, c+s):
				if self.board[i][j] != color:
					self.check = False
					return
		self.check = True
	def solution(self, s):
		answer = [0] * 2
		self.t = s
		for i in range(len(s)):
			self.board.append([0] * len(s[0]))
		self.func_@@@(@@@)
		self.func_@@@(@@@)
		answer[0] = self.w
		answer[1] = self.b
		return answer

s = ["11000011",
	 "11000011",
     "00001100",
	 "00001100",
	 "10001111",
	 "01001111",
	 "00111111",
	 "00111111"];
sol = Solution()
ret = sol.solution(s)
print("solution 함수의 반환값은", ret, "입니다.")