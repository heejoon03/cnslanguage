class Janggi:
    def __init__(self, row, col, cnt):
        self.row = row
        self.col = col
        self.cnt = cnt

def solution(horse, sol):
    answer = 0
    visit = []
    for i in range(10):
        visit.append([False] * 10)
    solRow = int(sol[0])
    solCol = int(sol[2])
    rowDir = [-2, -1, 1, 2, 2, 1, -1, -2]
    colDir = [-1, -2, -2, -1, 1, 2, 2, 1]
    h = Janggi(int(horse[0]), int(horse[2]), 0)
    visit[int(horse[0])][int(horse[2])] = True

    q = []
    q.append(h)

    while len(q) != 0:
        for i in range(8):
            nextRow = q[0].row + rowDir[i]
            nextCol = q[0].col + colDir[i]
            nextMove = q[0].cnt + 1
            if 1 <= nextRow <= 9 and 1 <= nextCol <= 9:
                if visit[nextRow][nextCol] == False:
                    t = Janggi(nextRow, nextCol, nextMove)
                    q.append(t)
        if @@@:
            answer = q[0].cnt
            @@@
        @@@
    return answer

horse = "3 5"
sol = "2 8"
ret = solution(horse, sol)
print("solution 함수의 반환값은", ret, "입니다.")