using System;
using System.Collections.Generic;

class MainClass
{
	public static List<string> solution(string[] timetable, string interval)
	{
		List<string> answer = new List<string>();

		int intervalToInt = (interval[0] - '0') * 10 + (interval[1] - '0');

		string startTime = timetable[0];
		string endTime = timetable[1];

		while(true)
        {
			int hour = (startTime[0] - '0') * 10 + (startTime[1] - '0');
			int min = (startTime[3] - '0') * 10 + (startTime[4] - '0');

			min += intervalToInt;

			if(min >= 60)
            {
				hour += (60 - min) + 10;
				min -= 60;
            }
			string cHour = hour.ToString();
			string cMin = min.ToString();

			if(cHour.Length == 1)
				cHour = "0" + cHour;
			if(cMin.Length == 1)
				cMin = "0" + cMin;

			startTime = cHour + ":" + cMin;

			int cStartTimeHour = (startTime[0] - '0') * 10 + (startTime[1] - '0');
			int cStartTimeMin = (startTime[3] - '0') * 10 + (startTime[4] - '0');
			int endTimeHour = (endTime[0] - '0') * 10 + (endTime[1] - '0');
			int endTimeMin = (endTime[3] - '0') * 10 + (endTime[4] - '0');


			if (cStartTimeHour > endTimeHour)
				break;
			else if (cStartTimeHour == endTimeHour && cStartTimeMin > endTimeMin)
				break;
			else if (cStartTimeHour == endTimeHour && cStartTimeMin == endTimeMin)
            {
				answer.Add(startTime);
				break;
			}
			answer.Add(startTime);
		}
		
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] timetable1 = {"12:00", "13:40"};
		string interval1 = "18";
		List<string> ret1 = solution(timetable1, interval1);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",",ret1) + "] 입니다.");

		string[] timetable2 = { "15:20", "17:40" };
		string interval2 = "20";
		List<string> ret2 = solution(timetable2, interval2);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",", ret2) + "] 입니다.");
	}
}
