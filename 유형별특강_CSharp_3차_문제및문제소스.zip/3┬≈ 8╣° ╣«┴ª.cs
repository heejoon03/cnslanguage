using System;
using System.Collections.Generic;

class MainClass
{
	public static int solution(string[] timetable)
	{
		int answer = 0;
		//여기를 구현해 주세요.
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] timetable1 = { "09:00:30", "12:20:50" };
		int ret1 = solution(timetable1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string[] timetable2 = {"12:00:00", "13:22:00"};
		int ret2 = solution(timetable2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}
