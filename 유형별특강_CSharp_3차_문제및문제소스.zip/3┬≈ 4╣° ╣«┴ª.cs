using System;
using System.Collections.Generic;
using System.Linq;

public class MainClass{

	static bool[] visit;
	static int[,] adj;
	static bool flag = false;
	static int n;
	static int k;
	static int a;
	static int b;
	static string ans;

	public static bool func_a(int v, string s)
    {
		if (v == b)
		{
			flag = true;
			ans = s;
		}
		else
		{
			for (int i = 1; i <= n; i++)
			{
				if (!visit[i] && adj[v, i] == 1)
				{
					visit[i] = true;
					func_@@@(@@@);
				}
			}
		}
		return flag;
	}

	public static void func_b(string[] x, int[] y)
    {
		n = x.GetLength(0);
		k = x[0].Length;
		a = y[0];
		b = y[1];
		ans = "";

		for (int i = 1; i < x.GetLength(0); i++)
		{
			for (int j = i + 1; j <= x.GetLength(0); j++)
			{
				if (func_@@@(@@@))
				{
					adj[i, j] = 1;
					adj[j, i] = 1;
				}
			}
		}
	}

	public static bool func_c(string s1, string s2)
    {
		int cnt = 0;
		for (int i = 0; i < k; i++)
		{
			if (s1[i] != s2[i])
			{
				if (++cnt >= 2)
				{
					return false;
				}
			}
		}
		if (cnt == 0)
			return false;
		return true;
	}

	public static string solution(string[] hamming, int[] question)
	{
		string answer = "";
		visit = new bool[1001];
		adj = new int[hamming.GetLength(0) + 1, hamming.GetLength(0) + 1];

		func_@@@(@@@);

		visit[question[0]] = true;

		if(!func_@@@(@@@))
			answer = "-1";
		else
			answer = ans;
		return answer;
	}

	public static void Main(string[] args){
		string[] hamming = { "000", "111", "010", "110", "001" };
		int[] question = { 1, 2 };
		string ret = solution(hamming, question);
		Console.WriteLine("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
