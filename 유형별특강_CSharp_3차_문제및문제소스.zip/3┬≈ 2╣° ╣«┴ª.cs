using System;
using System.Collections.Generic;

class MainClass
{
	public static int solution(string[] timetable, string disturb)
	{
		int answer = 0;

		int beginDisturbHour = (disturb[0] - '0') * 10 + (disturb[1] - '0');
		int endDisturbHour = (disturb[6] - '0') * 10 + (disturb[7] - '0');
		for (int i = 0; i < timetable.Length; i++)
        {
			int beginHour = (timetable[i][0] - '0') * 10 + (timetable[i][1] - '0');
			int endHour = (timetable[i][6] - '0') * 10 + (timetable[i][7] - '0');

			if(beginDisturbHour <= beginHour && endDisturbHour >= beginHour)
            {
				answer++;
			}
			else if(beginHour >= beginDisturbHour && endHour >= endDisturbHour) 
            {
				answer++;
			}
			else if(beginDisturbHour <= endHour && endDisturbHour >= endHour)
            {
				answer++;
			}
			else if(endDisturbHour <= beginHour && endDisturbHour >= endHour)
            {
				answer++;
			}
		}
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] timetable = {"08:00~10:00", "10:00~12:00", "12:00~14:00", "14:00~16:00"};
		string disturb = "11:00~13:00";
		int ret = solution(timetable, disturb);
		Console.WriteLine("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
