using System;
using System.Collections.Generic;

class MainClass
{
	public static int[] func_a(int[] arr, int len)
    {
		int[] answer = new int[len + 1];
		for(int i = 0; i < len; i++)
        {
			if(i == 0)
            {
				answer[i] = arr[i] - 8 * 60;
            }
			else
            {
				answer[i] = arr[i] - (arr[i - 1] + 60);
            }
        }
		answer[len] = 24 * 60 - (arr[len - 1] + 60);
		return answer;
    }

	public static int[] func_b(string[] arr, int len)
    {
		int[] answer = new int[len];
		for(int i = 0; i < len; i++)
        {
			int number1 = (arr[i][0] - '0') * 10 + (arr[i][1] - '0');
			int number2 = (arr[i][3] - '0') * 10 + (arr[i][4] - '0');
			answer[i] = number1 * 60 + number2;
        }
		return answer;
    }

	public static int func_c(int[] arr, int len)
    {
		int answer = 0;
		for(int i = 0; i < len; i++)
        {
			answer += arr[i];
        }
		return answer;
    }


	public static int solution(string[] timetable)
	{
		int[] occupied = func_@@@(@@@);
		int[] unoccupied = func_@@@(@@@);
		int answer = func_@@@(@@@);
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] timetable = { "11:30" , "16:00" };
		int ret = solution(timetable);
		Console.WriteLine("solution 함수의 반환 값은 " + ret + " 입니다.");
	}
}
