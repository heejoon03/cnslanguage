using System;
using System.Collections.Generic;
using System.Linq;

public class MainClass
{
	public static List<string> solution(string position)
	{
		List<string> answer = new List<string>();

		int[] rowDir = { 0, -1, 0, 1 };
		int[] colDir = { -1, 0, 1, 0 };

		char cIndex = position[0];
		char rIndex = position[1];

		for (int i = 0; i < 4; i++)
		{
			char moveCol = position[0];
			char moveRow = position[1];
			while (moveRow > @@@ && moveCol > @@@ && moveRow < @@@ && moveCol < @@@)
			{
				moveCol = (char)(@@@);
				moveRow = (char)(@@@);
				answer.Add(moveCol + "" + moveRow);
			}
		}

		return answer;
	}

	public static void Main(string[] args)
	{
		string position = "d4";
		List<string> ret = solution(position);
		Console.WriteLine("solution �Լ��� ��ȯ ���� [" + string.Join(",", ret) + "] �Դϴ�.");
	}
}
