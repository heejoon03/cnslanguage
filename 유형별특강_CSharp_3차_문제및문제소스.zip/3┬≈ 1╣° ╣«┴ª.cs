using System;

class MainClass
{
	public static int solution(string time, string eatMin)
	{
		int answer = 0;

		int beginHour = (time[0] - '0') * 10 + (time[1] - '0');
		int beginMin = (time[3] - '0') * 10 + (time[4] - '0');
		int endHour = (time[6] - '0') * 10 + (time[7] - '0');
		int endMin = (time[9] - '0') * 10 + (time[10] - '0');

		int eatMinToInt = (eatMin[0] - '0') * 10 + (eatMin[1] - '0');

		int totalTime = (endHour - beginHour) * 60 + (endMin + beginMin) % 60;

		answer = totalTime / eatMinToInt;

		return answer;
	}

	public static void Main(string[] args)
	{
		string time1 = "08:30~17:50";
		string eatMin1 = "70";
		int ret1 = solution(time1, eatMin1);
		Console.WriteLine("solution 함수의 반환 값은 " + ret1 + " 입니다.");

		string time2 = "15:12~19:34";
		string eatMin2 = "17";
		int ret2 = solution(time2, eatMin2);
		Console.WriteLine("solution 함수의 반환 값은 " + ret2 + " 입니다.");
	}
}

