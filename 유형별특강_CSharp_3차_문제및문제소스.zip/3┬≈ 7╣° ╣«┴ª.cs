using System;
using System.Collections.Generic;

class MainClass
{
	public static int[] solution(string[] timetable)
	{
		int[] answer = new int[4];
		//이곳을 구현해 주세요.	
		return answer;
	}

	public static void Main(string[] args)
	{
		string[] timetable = { "09:00:00~12:00:00" , "12:10:00~14:10:00" , "14:20:00~15:20:00" };
		int[] ret = solution(timetable);
		Console.WriteLine("solution 함수의 반환 값은 [" + string.Join(",", ret) + "] 입니다.");
	}
}
